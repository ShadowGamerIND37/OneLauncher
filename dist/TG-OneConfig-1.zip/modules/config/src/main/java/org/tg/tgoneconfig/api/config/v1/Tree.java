/*
 * This file is part of TGOneConfig.
 * TGOneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 TG.
 *   <https://github.com/ShadowGamerIND37> <https://github.com/TG/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   TGOneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to TGOneConfig, as published by TG,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to TGOneConfig, as published by TG. If not, see
 * <https://github.com/ShadowGamerIND37/legal/tgoneconfig/additional-terms>
 */

package org.tg.tgoneconfig.api.config.v1;

import org.jetbrains.annotations.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * The Tree class represents a tree structure that contains properties and other trees as children
 * <br>
 * It provides methods to access and modify and compare the tree and its elements
 */
@SuppressWarnings("unused")
public class Tree extends Node implements Serializable {
    @UnmodifiableView
    public final Map<String, Node> map;

    private final Map<String, Node> theMap;

    private static final ThreadLocal<List<String>> OVERWRITE_FAILURES = new ThreadLocal<>();

    public static void beginFailureCollection() {
        OVERWRITE_FAILURES.set(new ArrayList<>(2));
    }

    public static List<String> endFailureCollection() {
        List<String> out = OVERWRITE_FAILURES.get();
        OVERWRITE_FAILURES.remove();
        return out == null ? Collections.emptyList() : out;
    }

    @ApiStatus.Experimental
    public static List<String> collectFailures(@NotNull Runnable action) {
        beginFailureCollection();
        try {
            action.run();
        } catch (Throwable t) {
            endFailureCollection();
            throw t;
        }
        return endFailureCollection();
    }

    public Tree(@Nullable String id, @Nullable Object title, @Nullable Object description, @Nullable Map<String, Node> items) {
        super(id, title, description);
        if (items != null) {
            theMap = new LinkedHashMap<>(items.size());
            theMap.putAll(items);
        } else theMap = new LinkedHashMap<>();
        map = Collections.unmodifiableMap(theMap);
    }

    private static void _onAll(Tree t, BiConsumer<String, Node> action) {
        for (Map.Entry<String, Node> e : t.theMap.entrySet()) {
            action.accept(e.getKey(), e.getValue());
        }
    }

    private static void _onAllProp(Tree t, BiConsumer<String, Property<?>> action) {
        for (Map.Entry<String, Node> e : t.theMap.entrySet()) {
            if (e.getValue() instanceof Property) action.accept(e.getKey(), (Property<?>) e.getValue());
        }
    }

    private static void _overwrite(Tree self, Tree in, Function<String, String> keyMapper, boolean preserveMissingOptions, boolean skipOverwritten, @Nullable Tree root) {
        Node overwritten = null;
        if (root != null) {
            overwritten = root.get("reserved:overwritten");
        }
        for (Map.Entry<String, Node> from : in.theMap.entrySet()) {
            String key = keyMapper == null ? from.getKey() : keyMapper.apply(from.getKey());
            Node _this = self.get(key);
            Node that = from.getValue();
            if (_this == null) {
                // asm: node was removed so only re-add it when preserving
                if (preserveMissingOptions) {
                    self.put(that);
                }
                continue;
            }
            if (_this instanceof Tree) {
                if (skipOverwritten && overwritten instanceof Tree && !Objects.equals(((Tree) overwritten).get(that.getID()), null)) {
                    continue;
                }
                if (that instanceof Tree) {
                    _overwrite((Tree) _this, (Tree) that, keyMapper, preserveMissingOptions, skipOverwritten, root);
                    _this.addMetadata(that.getMetadata());
                    if (root != null) {
                        overwritten = root.getOrPutChild("reserved:overwritten");
                        ((Tree) overwritten).put(new Tree(that.getID(), null, null, null));
                    }
                }
                // do not attempt to overwrite a tree with a property
                else continue;
            }
            List<String> failures = OVERWRITE_FAILURES.get();
            if (failures != null) {
                try {
                    _this.overwrite(that, preserveMissingOptions, skipOverwritten, root);
                } catch (Throwable e) {
                    LOGGER.error("failed to apply stored value for '{}' (incompatible or corrupted); resetting it to its default", key, e);
                    failures.add(key);
                }
            } else {
                _this.overwrite(that, preserveMissingOptions, skipOverwritten, root);
            }
        }
    }

    private static void _unpack(Map<String, Object> out, Tree t) {
        for (Map.Entry<String, Node> e : t.theMap.entrySet()) {
            Node n = e.getValue();
            if (n instanceof Tree tt) {
                Map<String, Object> sub = new LinkedHashMap<>(tt.theMap.size());
                _unpack(sub, tt);
                out.put(e.getKey(), sub);
            } else {
                Property<?> p = (Property<?>) n;
                if (p.type == Void.class) continue;
                out.put(e.getKey(), p.get());
            }
        }
    }

    private static void _contentToString(StringBuilder sb, int depth, Tree t) {
        sb.repeat("\t", Math.max(0, depth));
        sb.append(t.getTitle()).append(":\n");
        for (Map.Entry<String, Node> e : t.theMap.entrySet()) {
            if (e.getValue() instanceof Property) {
                sb.repeat("\t", Math.max(0, depth + 1));
                sb.append(e.getValue()).append('\n');
            } else {
                _contentToString(sb, depth + 1, (Tree) e.getValue());
            }
        }
    }

    public static @NotNull Tree tree() {
        return new Tree(null, null, null, null);
    }

    @Contract("_, -> new")
    public static @NotNull Tree tree(@NotNull String id) {
        return new Tree(id, null, null, null);
    }

    /**
     * Create a new builder from the given tree
     * <br>
     * This will copy all the data from the tree into the builder
     */
    @Contract("_ -> new")
    public static @NotNull Tree tree(@NotNull Tree src) {
        return new Tree(src.getID(), src.getTitle(), src.description, src.theMap);
    }

    public Tree put(@NotNull Node... nodes) {
        for (Node n : nodes) {
            put(n);
        }
        return this;
    }

    public Tree put(Node n) {
        Node old = theMap.get(n.getID());
        if (old == n) return this;
        if (old != null) {
            n.overwrite(old, false);
        }
        theMap.put(n.getID(), n);
        return this;
    }

    @ApiStatus.Experimental
    public @Nullable Node remove(@NotNull String id) {
        return theMap.remove(id);
    }

    public Tree set(String id, Node n) {
        if (n.getID() == null) n.setID(id);
        else if (!id.equals(n.getID())) {
            //noinspection DataFlowIssue
            n.setID(null);
            n.setID(id);
        }
        put(n);
        return this;
    }

    @Nullable
    public Node get(String id) {
        return theMap.get(id);
    }

    @Nullable
    public Node get(@NotNull String... id) {
        Tree t = this;
        Node n = null;
        for (String s : id) {
            n = t.get(s);
            if (n instanceof Tree) t = (Tree) n;
            else return n;
        }
        return n;
    }

    @Nullable
    public Node get(@NotNull Iterable<String> id) {
        Tree t = this;
        Node n = null;
        for (String s : id) {
            n = t.get(s);
            if (n instanceof Tree) t = (Tree) n;
            else return n;
        }
        return n;
    }

    public Tree getChild(@NotNull String... id) {
        Node n = get(id);
        return n instanceof Tree ? (Tree) n : null;
    }

    public Tree getChild(@NotNull String id) {
        Node n = get(id);
        return n instanceof Tree ? (Tree) n : null;
    }

    public Tree getOrPutChild(@NotNull String id) {
        Tree n = getChild(id);
        if (n == null) {
            n = new Tree(id, null, null, null);
            put(n);
        }
        return n;
    }

    public Property<?> getProp(@NotNull String... id) {
        Node n = get(id);
        return n instanceof Property ? (Property<?>) n : null;
    }

    public Property<?> getProp(@NotNull String id) {
        Node n = get(id);
        return n instanceof Property ? (Property<?>) n : null;
    }

    public void onAll(BiConsumer<String, Node> action) {
        _onAll(this, action);
    }

    public void onAllProps(BiConsumer<String, Property<?>> action) {
        _onAllProp(this, action);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof Tree)) return false;
        Tree that = (Tree) obj;
        return this.theMap.size() == that.theMap.size() && this.getID().equals(that.getID());
    }

    /**
     * Check if the tree contents equal another tree
     * <br>
     * This checks the values and children of the tree
     *
     * @param obj the tree to check against
     * @return whether the trees are equal
     */
    public boolean deepEquals(@Nullable Object obj) {
        if (!equals(obj)) return false;
        Tree that = (Tree) obj;
        for (Map.Entry<String, Node> e : this.theMap.entrySet()) {
            Node n = that.get(e.getKey());
            if (n == null) {
                return false;
            }
            if (!e.getValue().deepEquals(n)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Overwrite this tree with the supplied tree using the keyMapper to map between key names from old to new if needed
     *
     * @param with      the tree to overwrite with
     * @param keyMapper the key mapper function to use
     */
    public void overwrite(Tree with, @NotNull Function<String, String> keyMapper, boolean preserveMissingOptions, boolean skipOverwritten, @Nullable Tree root) {
        _overwrite(this, with, keyMapper, preserveMissingOptions, skipOverwritten, root);
    }

    @Override
    public void overwrite(@NotNull Node with, boolean preserveMissingOptions, boolean skipOverwritten, @Nullable Tree root) {
        if (!(with instanceof Tree)) throw new IllegalArgumentException("Cannot overwrite a tree with a non-tree node!");
        if (skipOverwritten && root == null) {
            throw new IllegalArgumentException("Cannot mark overwritten without a root tree!");
        }
        Map<String, String> migrationMap = getMetadata("migrationMap");
        if (migrationMap == null) {
            _overwrite(this, (Tree) with, null, preserveMissingOptions, skipOverwritten, root);
        } else {
            _overwrite(this, (Tree) with, migrationMap::get, preserveMissingOptions, skipOverwritten, root);
        }
    }

    /**
     * Unpack this tree into a map of objects containing either more Maps or the values of the properties of this tree
     */
    public Map<String, Object> unpack() {
        Map<String, Object> out = new LinkedHashMap<>(theMap.size());
        _unpack(out, this);
        return out;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(72);
        sb.append("Tree(id=").append(getID());
        if (getTitle() != null) sb.append(", title=").append(getTitle());
        if (description != null) sb.append(", description=").append(description);
        sb.append(", theMap=").append(theMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue().toString()).collect(Collectors.joining(",","{","}")));
        sb.append(", size=").append(theMap.size()).append(')');
        return sb.toString();
    }

    public String contentToString() {
        StringBuilder sb = new StringBuilder(128);
        _contentToString(sb, 0, this);
        return sb.toString();
    }

    /**
     * Clear this tree of all its members
     * <br>
     * This function is used internally to discard trees to prevent illegal usage of 'dead' trees
     */
    @ApiStatus.Internal
    public void clear() {
        theMap.clear();
        clearMetadata();
    }

    /**
     * Figure out what the path from the given root to the given node is
     */
    public static String evaluatePath(Tree root, Node node) {
        if (node == null || root == null) return null;
        StringBuilder sb = new StringBuilder(32);
        _evaluatePath(sb, root, node);
        return sb.toString();

    }

    private static boolean _evaluatePath(StringBuilder sb, Tree root, Node node) {
        if (root == node) {
            if (!sb.isEmpty()) sb.append('.');
            sb.append(node.getID());
            return true;
        }
        for (Map.Entry<String, Node> e : root.theMap.entrySet()) {
            if (e.getValue() == node) {
                if (!sb.isEmpty()) sb.append('.');
                sb.append(e.getKey());
                return true;
            }
            if (e.getValue() instanceof Tree) {
                boolean found = _evaluatePath(sb, (Tree) e.getValue(), node);
                if (found) {
                    sb.append('.').append(e.getKey());
                    return true;
                }
            }
        }
        return false;
    }
}
