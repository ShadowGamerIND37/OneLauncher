plugins {
    id("tgoneconfig-setup")
}
