package org.tg.tgoneconfig.api.platform.v1.internal;

import net.minecraft.client.Minecraft;
import org.tg.tgoneconfig.api.platform.v1.Options;

public class OptionsImpl implements Options {
    @Override
    public float getGuiScale() {
        // effective scale never 0 or Auto and matches what GlHost.blitHud uses
        // options.guiScale().get() returns the raw option which mis-sizes the HUD into the top-left
        return (float) Minecraft.getInstance().getWindow().getGuiScale();
    }
}
