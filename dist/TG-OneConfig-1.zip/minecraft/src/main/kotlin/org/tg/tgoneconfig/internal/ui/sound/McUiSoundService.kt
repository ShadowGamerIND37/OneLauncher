package org.tg.tgoneconfig.internal.ui.sound

import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import java.util.concurrent.atomic.AtomicLong
import net.minecraft.client.Minecraft
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance
import net.minecraft.client.resources.sounds.SimpleSoundInstance
import net.minecraft.client.resources.sounds.SoundInstance
import net.minecraft.client.gui.screens.Screen
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvents
import net.minecraft.sounds.SoundSource
import org.tg.tgoneconfig.api.platform.v1.Platform

//? if > 1.8.9 {
import net.minecraft.core.Holder
import net.minecraft.sounds.SoundEvent
import net.minecraft.util.RandomSource
//?}

class McUiSoundService : UiSoundService {
    private val sliderTick = AtomicInteger(0)

    @Volatile
    private var ambience: FadingLoopSoundInstance? = null

    @Volatile
    private var ambienceWatchThread: Thread? = null

    private val ambienceShuffle = mutableMapOf<UiSoundTheme, MutableList<String>>()
    private val lastAmbienceSoundId = mutableMapOf<UiSoundTheme, String>()

    private val mc get() = Minecraft.getInstance()

    override fun play(event: UiSoundEvent, theme: UiSoundTheme, volume: Float) {
        if (volume <= 0f) return
        try {
            when (theme) {
                UiSoundTheme.MODERN -> playModern(event, volume)
                UiSoundTheme.MINECRAFT -> playMinecraft(event, volume)
            }
        } catch (_: Throwable) {
        }
    }

    private fun playModern(event: UiSoundEvent, volume: Float) {
        when (event) {
            UiSoundEvent.OPEN -> playModernSound("ui.open", 1f, volume)
            UiSoundEvent.CLOSE -> playModernSound("ui.close", 1f, volume)
            UiSoundEvent.CLICK -> playModernSound("ui.click", 1f, volume)
            UiSoundEvent.SLIDER_TICK -> playModernSound("ui.slider", 1f, volume)
            UiSoundEvent.HUD_SELECT -> playModernSound("ui.click", 1.0f, volume)
            UiSoundEvent.HUD_DRAG_START -> playModernSound("ui.click", 0.9f, volume)
            UiSoundEvent.HUD_DRAG_END -> playModernSound("ui.click", 1.1f, volume)
            UiSoundEvent.HUD_RESIZE_END -> playModernSound("ui.click", 1.0f, volume)
            else -> { }
        }
    }

    private fun playModernSound(id: String, pitch: Float, volume: Float) {
        //? if > 1.8.9 {
        val event = SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("tgoneconfig", id))
        //?} else
        //val event = Identifier("tgoneconfig", id)
        mc.soundManager.play(SimpleSoundInstance.forUI(event, pitch, volume.coerceIn(0f, 1f)))
    }

    private fun playMinecraft(event: UiSoundEvent, volume: Float) {
        when (event) {
            UiSoundEvent.CLICK -> playVanilla(SoundEvents.UI_BUTTON_CLICK, 1f, 0.5f * volume)
            UiSoundEvent.OPEN -> playModernSound("ui.open", 1f, volume)
            UiSoundEvent.CLOSE -> playModernSound("ui.close", 1f, volume)
            UiSoundEvent.SLIDER_TICK -> {
                val steps = floatArrayOf(1.334840f, 1.414214f, 1.498307f, 1.587401f, 1.681793f, 1.781797f)
                val pitch = steps[sliderTick.getAndIncrement().mod(steps.size)]
                playVanilla(SoundEvents.NOTE_BLOCK_BASS, pitch, 0.3f * volume)
            }
            UiSoundEvent.HUD_SELECT -> playVanilla(SoundEvents.UI_BUTTON_CLICK, 1f, 0.3f * volume)
            UiSoundEvent.HUD_DRAG_END -> playVanilla(SoundEvents.UI_BUTTON_CLICK, 1f, 0.3f * volume)
            UiSoundEvent.HUD_RESIZE_END -> playVanilla(SoundEvents.UI_BUTTON_CLICK, 1f, 0.3f * volume)
            else -> { }
        }
    }

    //~ if = 1.8.9 'SoundEvent' -> 'Identifier'
    private fun playVanilla(event: SoundEvent, pitch: Float, volume: Float) {
        mc.soundManager.play(SimpleSoundInstance.forUI(event, pitch, volume.coerceIn(0f, 1f)))
    }

    //? if > 1.8.9 {
    @Suppress("unused")
    private fun playVanilla(holder: Holder<SoundEvent>, pitch: Float, volume: Float) =
        playVanilla(holder.value(), pitch, volume)
    //?}

    override fun startAmbience(theme: UiSoundTheme, volume: Float) {
        try {
            val current = ambience
            if (current != null && !current.isStopped && current.theme == theme && isAlive(current)) {
                current.updateTargetVolume(ambienceVolumeFor(theme, volume))
                current.cancelFadeOut()
                UiSoundDucking.setActive(true)
                driveAmbienceLoop()
                driveMusicDuckFade()
                return
            }
            if (current != null && !current.isStopped) {
                try {
                    mc.soundManager.stop(current)
                } catch (_: Throwable) {
                }
            }
            playAmbienceInstance(theme, ambienceVolumeFor(theme, volume), fadeIn = !willPause())
            UiSoundDucking.setActive(true)
            driveAmbienceLoop()
            driveMusicDuckFade()
        } catch (_: Throwable) {
        }
    }

    override fun stopAmbience(setDucking: Boolean) {
        val instance = ambience ?: return
        if (instance.isStopped) {
            ambience = null
            return
        }
        instance.beginFadeOut()
        UiSoundDucking.setActive(setDucking)
        driveMusicDuckFade()
    }

    private fun ambienceVolumeFor(theme: UiSoundTheme, volume: Float): Float = when (theme) {
        UiSoundTheme.MODERN -> 0.5f * volume
        UiSoundTheme.MINECRAFT -> 0.08f * volume
    }.coerceIn(0f, 1f)

    private fun ambienceSoundIds(theme: UiSoundTheme): List<String> = when (theme) {
        UiSoundTheme.MODERN -> listOf("ui.pad_loop")
        UiSoundTheme.MINECRAFT -> listOf(
            "ui.mc_ambient.trees",
            "ui.mc_ambient.moog_1",
            "ui.mc_ambient.moog_2",
            "ui.mc_ambient.lullaby",
        )
    }

    private fun playAmbienceInstance(
        theme: UiSoundTheme,
        targetVolume: Float,
        fadeIn: Boolean,
    ) {
        val soundIds = ambienceSoundIds(theme)
        val soundId = nextAmbienceSoundId(theme, soundIds)
        //? if > 1.8.9 {
        val event = SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("tgoneconfig", soundId))
        //?} else
        //val event = Identifier("tgoneconfig", soundId)
        //? if >= 1.21.6 {
        val source = SoundSource.UI
        //?} elif > 1.8.9 {
        /*val source = SoundSource.MASTER
        *///? }
        //~ if = 1.8.9 '(event, source,' -> '(event,'
        val instance = FadingLoopSoundInstance(event, source, targetVolume, theme, soundIds.size == 1, fadeIn)
        ambience = instance
        mc.soundManager.play(instance)
    }

    @Synchronized
    private fun nextAmbienceSoundId(theme: UiSoundTheme, ids: List<String>): String {
        if (ids.size == 1) return ids.first()

        val queue = ambienceShuffle.getOrPut(theme) { mutableListOf() }
        if (queue.isEmpty()) {
            queue += ids
            queue.shuffle()
            val last = lastAmbienceSoundId[theme]
            if (queue.first() == last) {
                val swapIndex = queue.indexOfFirst { it != last }
                if (swapIndex > 0) {
                    val first = queue[0]
                    queue[0] = queue[swapIndex]
                    queue[swapIndex] = first
                }
            }
        }

        return queue.removeAt(0).also { lastAmbienceSoundId[theme] = it }
    }

    private fun driveAmbienceLoop() {
        if (ambienceWatchThread?.isAlive == true) return
        val thread = Thread {
            try {
                while (true) {
                    Thread.sleep(500L)
                    mc.execute {
                        try {
                            val current = ambience ?: return@execute
                            if (current.isStopped || current.isFadingOut || current !== ambience) return@execute
                            if (!isAlive(current)) {
                                mc.soundManager.stop(current)
                                playAmbienceInstance(current.theme, current.targetVolume, fadeIn = !willPause())
                            }
                        } catch (_: Throwable) {
                        }
                    }
                    if (ambience == null || ambience?.isStopped == true) return@Thread
                }
            } catch (_: InterruptedException) {
            }
        }
        thread.isDaemon = true
        thread.name = "TG OneConfig-AmbienceLoop"
        ambienceWatchThread = thread
        thread.start()
    }

    private fun isAlive(instance: FadingLoopSoundInstance): Boolean =
        mc.soundManager.isActive(instance) ||
            !instance.startedSilent && System.currentTimeMillis() - instance.startedAt < START_GRACE_MS

    private fun willPause(): Boolean {
        if (mc.isPaused) return true
        val screen = Platform.screen().current<Screen>() ?: return false
        //~ if = 1.8.9 'singleplayerServer' -> 'server'
        val integrated = mc.singleplayerServer ?: return false
        return mc.isLocalServer && screen.isPauseScreen && !integrated.isPublished
    }

    private val musicRefreshUntil = AtomicLong(0)

    @Volatile
    private var musicRefreshThread: Thread? = null

    private fun driveMusicDuckFade() {
        musicRefreshUntil.set(System.currentTimeMillis() + UiSoundDucking.FADE_MS.toLong() + 150L)
        if (musicRefreshThread?.isAlive == true) return
        val thread = Thread {
            try {
                do {
                    mc.execute {
                        try {
                            //? if >= 1.21.11 {
                            mc.soundManager.refreshCategoryVolume(SoundSource.MUSIC)
                            //? } else if >= 1.21.10 {
                            /*mc.soundManager.updateSourceVolume(SoundSource.MUSIC)
                            *///? } else {
                            /*//~ if = 1.8.9 'SoundSource' -> 'SoundCategory'
                            mc.soundManager.updateSourceVolume(SoundSource.MUSIC, mc.options.getSoundSourceVolume(SoundSource.MUSIC))
                            *///? }
                        } catch (_: Throwable) {
                        }
                    }
                    Thread.sleep(25L)
                } while (System.currentTimeMillis() < musicRefreshUntil.get())
            } catch (_: InterruptedException) {
            }
        }
        thread.isDaemon = true
        thread.name = "TG OneConfig-MusicDuck"
        musicRefreshThread = thread
        thread.start()
    }

    private inner class FadingLoopSoundInstance(
        //~ if = 1.8.9 'SoundEvent' -> 'Identifier'
        event: SoundEvent,
        //? if > 1.8.9
        source: SoundSource,
        @Volatile var targetVolume: Float,
        val theme: UiSoundTheme,
        private val nativeLoop: Boolean,
        fadeIn: Boolean,
        //~ if = 1.8.9 '(event, source, RandomSource.create())' -> '(event)'
    ) : AbstractTickableSoundInstance(event, source, RandomSource.create()) {

        @Volatile
        private var fadingOut = false

        @Volatile
        private var lastTickAt = System.nanoTime()

        @Volatile
        private var rampStep = maxOf(targetVolume, FADE_IN_FLOOR) / FADE_IN_TICKS

        @Volatile
        private var fadeOutStep = 0f

        val startedAt = System.currentTimeMillis()

        val startedSilent = !fadeIn && targetVolume <= 0f

        val isFadingOut: Boolean
            get() = fadingOut

        private val ticksStalled: Boolean
            get() = System.nanoTime() - lastTickAt > STALL_NANOS

        init {
            looping = nativeLoop
            //? if > 1.8.9 {
            delay = 0
            //?} else
            //period = 0
            attenuation = SoundInstance.Attenuation.NONE
            //? if > 1.8.9
            relative = true
            //? if = 1.8.9 {
            /*moveToListener()
            *///?}
            volume = if (fadeIn) FADE_IN_FLOOR else targetVolume
            pitch = 1f
        }

        fun beginFadeOut() {
            fadeOutStep = maxOf(volume, FADE_IN_FLOOR) / FADE_TICKS
            fadingOut = true
        }

        fun cancelFadeOut() {
            fadingOut = false
            retarget()
        }

        fun updateTargetVolume(newTarget: Float) {
            targetVolume = newTarget
            retarget()
        }

        private fun retarget() {
            if (ticksStalled) volume = targetVolume
            rampStep = maxOf(abs(targetVolume - volume), FADE_IN_FLOOR) / FADE_IN_TICKS
        }

        //? if = 1.8.9 {
        /*private fun moveToListener() {
            val listener = SimpleSoundInstance.listenerPosition()
            x = listener[0]
            y = listener[1]
            z = listener[2]
        }
        *///?}

        override fun tick() {
            lastTickAt = System.nanoTime()
            //? if = 1.8.9 {
            /*moveToListener()
            *///?}
            if (fadingOut) {
                volume -= fadeOutStep
                if (volume <= 0f) {
                    volume = 0f
                    //$ if > 1.8.9 'stop()' else 'done = true'
                    stop()
                }
                return
            }
            val target = targetVolume
            volume = when {
                volume < target -> minOf(target, volume + rampStep)
                volume > target -> maxOf(target, volume - rampStep)
                else -> volume
            }
        }
    }

    private companion object {
        const val FADE_TICKS = 80f
        const val FADE_IN_TICKS = 30f
        const val FADE_IN_FLOOR = 0.0001f
        const val STALL_NANOS = 400_000_000L
        const val START_GRACE_MS = 5000L
    }
}
