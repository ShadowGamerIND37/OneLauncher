import com.google.devtools.ksp.gradle.KspExtension
import dev.kikugie.stonecutter.build.StonecutterBuildExtension
import gg.essential.gradle.util.RelocationTransform.Companion.registerRelocationAttribute
import gg.essential.gradle.util.prebundle
import org.gradle.api.JavaVersion
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.artifacts.Configuration
import org.gradle.api.artifacts.ExternalModuleDependency
import org.gradle.api.artifacts.ExternalModuleDependencyBundle
import org.gradle.api.artifacts.VersionCatalogsExtension
import org.gradle.api.plugins.JavaPluginExtension
import org.gradle.api.provider.Provider
import org.gradle.api.publish.PublishingExtension
import org.gradle.api.publish.maven.MavenPublication
import org.gradle.api.tasks.SourceSetContainer
import org.gradle.api.tasks.bundling.Jar
import org.gradle.api.tasks.compile.JavaCompile
import org.gradle.authentication.http.BasicAuthentication
import org.gradle.kotlin.dsl.apply
import org.gradle.kotlin.dsl.configure
import org.gradle.kotlin.dsl.create
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.exclude
import org.gradle.kotlin.dsl.get
import org.gradle.kotlin.dsl.getByType
import org.gradle.kotlin.dsl.invoke
import org.gradle.kotlin.dsl.maven
import org.gradle.kotlin.dsl.named
import org.gradle.kotlin.dsl.register
import org.gradle.kotlin.dsl.repositories
import org.gradle.kotlin.dsl.withType
import org.gradle.language.jvm.tasks.ProcessResources
import org.gradle.plugins.signing.SigningExtension
import org.jetbrains.kotlin.gradle.dsl.KotlinJvmExtension
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

class TGOneConfigSetupPlugin : Plugin<Project> {
    override fun apply(target: Project): Unit = with(target) {
        pluginManager.apply("java-library")
        pluginManager.apply("org.jetbrains.kotlin.jvm")
        pluginManager.apply("org.jetbrains.kotlin.plugin.compose")
        pluginManager.apply("com.google.devtools.ksp")
        pluginManager.apply("maven-publish")
        pluginManager.apply(TGOneConfigLintPlugin::class.java)

        repositories {
            fun scopedMaven(url: String, vararg groups: String) = maven(url) {
                content { for (group in groups) includeGroupAndSubgroups(group) }
            }

            scopedMaven("https://repo.polyfrost.org/releases", "org.polyfrost", "org.tg")
            scopedMaven("https://repo.polyfrost.org/snapshots", "org.polyfrost", "org.tg")
            scopedMaven("https://repo.hypixel.net/repository/Hypixel/", "net.hypixel")
            scopedMaven("https://maven.deftu.dev/releases", "dev.deftu")
            scopedMaven("https://maven.notenoughupdates.org/releases/", "org.notenoughupdates")
            scopedMaven("https://maven.teamresourceful.com/repository/maven-releases", "com.teamresourceful")
            scopedMaven("https://maven.isxander.dev/releases", "dev.isxander")
            scopedMaven("https://api.modrinth.com/maven", "maven.modrinth") // some yacl versions only exist here and not on the official repo
            scopedMaven("https://jitpack.io", "com.github")
            scopedMaven("https://maven.terraformersmc.com/releases", "com.terraformersmc")
            scopedMaven("https://maven.teamresourceful.com/repository/maven-public/", "me.owdding", "tech.thatgravyboat")
            scopedMaven("https://maven.azureaaron.net/releases", "net.azureaaron")
            scopedMaven("https://maven.bawnorton.com/releases", "com.github.bawnorton")
            scopedMaven("https://redirector.kotlinlang.org/maven/compose-dev", "org.jetbrains")
            scopedMaven("https://central.sonatype.com/repository/maven-snapshots/", "net.kyori")
            scopedMaven("https://maven.azureaaron.net/snapshots", "net.azureaaron")
            google()
            mavenLocal()
        }

        evaluationDependsOn(":modules")
        val polyComposeVersion = versionedCatalog.versions["polycompose"].requiredVersion

        // nested into the jar shipped to players by TGOneConfigDistributionPlugin
        configurations.dependencyScope("bundle")

        val sourceSets = extensions.getByType<SourceSetContainer>()
        configure<JavaPluginExtension> {
            withSourcesJar()
            registerFeature("oneConfigModules") {
                usingSourceSet(sourceSets.create("oneConfigModules"))
            }
        }

        val stonecutter = project.extensions.getByName("stonecutter") as StonecutterBuildExtension
        val loader = stonecutter.current.project.substringAfterLast("-")
        val enableMoulRelocatorKsp = loader == "fabric" && versionedCatalog.has("moulconfig")

        if (loader == "fabric") {
            val modMenuShimClasses = layout.buildDirectory.dir("classes/modMenuShim")
            val compileModMenuApiShimJava = tasks.register<JavaCompile>("compileModMenuApiShimJava") {
                val mainSourceSet = sourceSets.named("main").get()
                javaCompiler.set(tasks.named<JavaCompile>("compileJava").flatMap { it.javaCompiler })
                source(rootProject.projectDir.resolve("minecraft/src/modMenuShim/java"))
                classpath = files(mainSourceSet.output.classesDirs, mainSourceSet.compileClasspath)
                destinationDirectory.set(modMenuShimClasses)
                dependsOn(tasks.named("compileJava"), tasks.named("compileKotlin"))
            }
            val modMenuApiShimJar = tasks.register<Jar>("modMenuApiShimJar") {
                archiveFileName.set("modmenu-api-shim.jar")
                from(modMenuShimClasses)
                dependsOn(compileModMenuApiShimJava)
            }
            tasks.named<ProcessResources>("processResources") {
                from(modMenuApiShimJar) {
                    into("META-INF/tgoneconfig")
                }
            }
        }

        // The legacy fade_in_blur post/program shaders use the pre-1.21.4 format and are unused on 1.21.1+
        if (stonecutter.eval(stonecutter.current.version, ">= 1.21.4")
            && stonecutter.eval(stonecutter.current.version, "< 1.21.5")) {
            tasks.named<ProcessResources>("processResources") {
                exclude("assets/minecraft/shaders/post/fade_in_blur.json")
                exclude("assets/minecraft/shaders/program/fade_in_blur.json")
                exclude("assets/minecraft/shaders/program/fade_in_blur.fsh")
            }
        }

        configurations.configureEach {
            exclude(group = "org.jetbrains.skiko")
            exclude(group = "org.jetbrains.compose.ui", module = "ui-skiko")
            exclude(group = "org.jetbrains.compose.ui", module = "ui-skiko-desktop")
            exclude(group = "org.jetbrains.compose.ui", module = "ui")
            exclude(group = "org.jetbrains.compose.ui", module = "ui-desktop")
        }

        val skyhanniRelocated = registerRelocationAttribute("relocate-skyhanni-moulconfig") {
            relocate("io.github.notenoughupdates.moulconfig", "at.hannibal2.skyhanni.deps.moulconfig")
        }

        val skyhanniRelocatedConfiguration: Configuration = configurations.create("skyhanniRelocatedConfiguration") {
            attributes { attribute(skyhanniRelocated, true) }
        }

        val firmamentRelocated = registerRelocationAttribute("relocate-firmament-moulconfig") {
            relocate("io.github.notenoughupdates.moulconfig", "moe.nea.firmament.deps.moulconfig")
        }

        val firmamentRelocatedConfiguration: Configuration = configurations.create("firmamentRelocatedConfiguration") {
            attributes { attribute(firmamentRelocated, true) }
        }

        val skysoftRelocated = registerRelocationAttribute("relocate-skysoft-moulconfig") {
            relocate("io.github.notenoughupdates.moulconfig", "com.skysoft.deps.softconfig")
        }

        val skysoftRelocatedConfiguration: Configuration = configurations.create("skysoftRelocatedConfiguration") {
            attributes { attribute(skysoftRelocated, true) }
        }

        val adventurePlatform = when {
            loader != "fabric" -> null
            stonecutter.eval(stonecutter.current.version, ">= 26.3") -> "7.2.0"
            stonecutter.eval(stonecutter.current.version, ">= 26.2") -> "7.1.1"
            stonecutter.eval(stonecutter.current.version, ">= 26.1") -> "6.9.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.11") -> "6.8.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.10") -> "6.7.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.8") -> "6.6.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.5") -> "6.4.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.4") -> "6.3.0"
            stonecutter.eval(stonecutter.current.version, ">= 1.21.1") -> "5.14.2"
            else -> error("No adventure-platform-fabric version for ${stonecutter.current.version}")
        }?.let { "net.kyori:adventure-platform-fabric:$it" }

        dependencies {
            listOf("compat", "common-compat").forEach {
                versionedCatalog.bundles.getOrNull(it)?.let { bundle ->
                    "modCompileOnly"(bundle) {
                        isTransitive = false
                    }
                }
            }
            fun moulConfig(vararg configurations: Configuration) {
                if (!versionedCatalog.has("moulconfig")) return
                "compileOnly"(versionedCatalog["moulconfig"])
                configurations.forEach { configuration ->
                    configuration(versionedCatalog["moulconfig"])
                    "compileOnly"(prebundle(configuration))
                }
            }

            moulConfig(skyhanniRelocatedConfiguration, firmamentRelocatedConfiguration, skysoftRelocatedConfiguration)

            "api"(versionedCatalog["commonmark"])
            "modApi"("org.polyfrost:polycompose-${stonecutter.current.project}:$polyComposeVersion")
            handleApiDep(versionedCatalog.bundles["adventure"])

            if (adventurePlatform != null) {
                "modApi"(adventurePlatform) { exclude("net.fabricmc.fabric-api") }
                "modImplementation"(adventurePlatform) { exclude("net.fabricmc.fabric-api") }
                "bundle"(adventurePlatform)
            }

            // Fabric Language Kotlin is a standalone mod that ships these
            handleApiDep(versionedCatalog.bundles["kotlin"], bundle = false)
            handleApiDep(versionedCatalog.bundles["kotlinx"], bundle = false)
            handleApiDep(versionedCatalog.bundles["nightconfig"])
            handleApiDep(versionedCatalog["snakeyaml"])
            handleApiDep(versionedCatalog.bundles["twelvemonkeys"])
            handleApiDep(versionedCatalog["java-objc-bridge"])
            val hypixelModApiVersion = if (stonecutter.eval(stonecutter.current.version, ">= 26.1") || loader == "ornithe") "1.0.2" else "1.0.1"
            // the bundled Hypixel Mod API mod ships it
            handleApiDep("net.hypixel:mod-api:$hypixelModApiVersion", bundle = false)
            handleApiDep(versionedCatalog["hypixel-data"])

            if (loader == "fabric") {
                val hypixelFabricMod =
                    if (stonecutter.eval(stonecutter.current.version, ">= 26.1")) {
                        "maven.modrinth:hypixel-mod-api:1.0.2+build.1+mc26.1"
                    } else {
                        "maven.modrinth:hypixel-mod-api:1.0.1+build.1+mc1.21"
                    }
                if (stonecutter.eval(stonecutter.current.version, ">= 26.1")) {
                    "implementation"(hypixelFabricMod) { isTransitive = false }
                } else {
                    "modImplementation"(hypixelFabricMod) { isTransitive = false }
                }
                "bundle"(hypixelFabricMod)
            } else if (loader == "ornithe") {
                val hypixelOrnitheMod = "org.polyfrost:mod-api-fabric:1.0.2+build.3+mc1.8.9"
                "modLocalRuntime"(hypixelOrnitheMod) { isTransitive = false }
                "bundle"(hypixelOrnitheMod)
            }

            handleApiDep(versionedCatalog["mixin-squared"])
            // MixinSquared's API extends ASM types without declaring ASM. Loom's source remapper for dependents only sees
            // mod dependencies, not Fabric Loader's libraries, and crashes when it can't resolve those supertypes.
            handleApiDep(versionedCatalog["asm-tree"], transitive = true, bundle = false)
            handleApiDep(versionedCatalog["commonmark"])

            if (loader == "fabric") {
                handleApiDep(versionedCatalog["fabric-language-kotlin"], bundle = false)
                handleApiDep(versionedCatalog["fabric-loader"], isMod = true, transitive = true, bundle = false)

                val fullFabricApiVersion = when {
                    stonecutter.eval(stonecutter.current.version, ">= 26.3") -> "0.160.3+26.3"
                    stonecutter.eval(stonecutter.current.version, ">= 26.2") -> "0.159.0+26.2"
                    stonecutter.eval(stonecutter.current.version, ">= 26.1") -> "0.155.2+26.1.2"
                    stonecutter.eval(stonecutter.current.version, ">= 1.21.11") -> "0.141.6+1.21.11"
                    stonecutter.eval(stonecutter.current.version, ">= 1.21.10") -> "0.138.4+1.21.10"
                    stonecutter.eval(stonecutter.current.version, ">= 1.21.8") -> "0.136.1+1.21.8"
                    stonecutter.eval(stonecutter.current.version, ">= 1.21.5") -> "0.128.2+1.21.5"
                    stonecutter.eval(stonecutter.current.version, ">= 1.21.4") -> "0.119.4+1.21.4"
                    else -> "0.116.17+1.21.1"
                }
                "modApi"("net.fabricmc.fabric-api:fabric-api:$fullFabricApiVersion")
            }

            if (versionedCatalog.has("cinnabar") && project.hasProperty("minecraft.vulkan")) {
                handleApiDep(versionedCatalog["cinnabar"])
            }

            if (versionedCatalog.has("vulkanmod")) {
                "modCompileOnly"(versionedCatalog["vulkanmod"]) { isTransitive = false }
                "compileOnly"(versionedCatalog["lwjgl-vulkan"])
            }

            if (versionedCatalog.has("meowdding-lib")) {
                val mcVersion = stonecutter.current.version
                "compileOnly"(versionedCatalog["meowdding-lib"]) {
                    isTransitive = false
                    capabilities { requireCapability("me.owdding.meowdding-lib:meowdding-lib-$mcVersion") }
                }
                "compileOnly"(versionedCatalog["skyblock-api"]) {
                    isTransitive = false
                    capabilities { requireCapability("tech.thatgravyboat:skyblock-api-$mcVersion") }
                }
            }

            "annotationProcessor"(versionedCatalog["mixin.squared"])

            if (enableMoulRelocatorKsp) {
                "ksp"(project(":modules:relocator"))
            }

            for (project in rootProject.project(":modules").subprojects) {
                if ("relocator" in project.path) {
                    "compileOnly"(project(project.path))
                } else {
                    "api"(project(project.path))
                    "bundle"(project(project.path))
                }
            }
        }

        if (enableMoulRelocatorKsp) {
            extensions.configure<KspExtension> {
                arg("relocator.mcVersion", stonecutter.current.version)
            }
        } else {
            tasks.matching { it.name.startsWith("ksp") }.configureEach {
                enabled = false
            }
        }

        group = rootProject.group
        version = rootProject.version

        afterEvaluate {
            configure<PublishingExtension> {
                repositories {
                    listOf("releases", "snapshots").forEach { type ->
                        maven {
                            name = type
                            url = uri("https://repo.polyfrost.org/$type")
                            credentials {
                                username = providers.gradleProperty("polyfrostRepoUsername").orNull
                                password = providers.gradleProperty("polyfrostRepoToken").orNull
                            }
                            authentication { create<BasicAuthentication>("basic") }
                        }
                    }
                }

                publications {
                    create<MavenPublication>("mavenJava") {
                        from(components["java"])
                        groupId = rootProject.group.toString()
                        artifactId = project.name
                        suppressAllPomMetadataWarnings()
                    }
                }
            }

            // Ploceus owns a configuration also named "signatures", which the signing plugin warns about
            if (providers.gradleProperty("signing.keyId").isPresent) {
                apply(plugin = "signing")
                configure<SigningExtension> {
                    sign(extensions.getByType<PublishingExtension>().publications["mavenJava"])
                }
            }
        }

        tasks.withType<ProcessResources>() {
            val range = if (versionedCatalog.versions.has("minecraft.range")) {
                versionedCatalog.versions.get("minecraft.range").toString()
            } else {
                val start = versionedCatalog.versions.getOrFallback("minecraft.start", "minecraft")
                val end = versionedCatalog.versions.getOrFallback("minecraft.end", "minecraft")
                ">=$start <=$end"
            }
            val version = project.version

            val fabricProperties = buildMap {
                put("mod_version", version)
                put("fabric_mc_version", range)
                put("loader_version", versionedCatalog.versions["loader"].requiredVersion)
                put("flk_version", versionedCatalog.versions["fabric-language-kotlin"].requiredVersion)
                put("polycompose_version", polyComposeVersion)
            }

            this.inputs.properties(fabricProperties)

            this.filesMatching(if (loader == "ornithe") "ornithe.mod.json" else "fabric.mod.json") {
                expand(fabricProperties)
            }
            if (loader == "ornithe") {
                exclude("fabric.mod.json")
                eachFile { if (path == "ornithe.mod.json") path = "fabric.mod.json" }
            } else {
                exclude("ornithe.mod.json")
            }

            val mixinCompat = if (
                stonecutter.eval(stonecutter.current.version, ">= 26.1") ||
                stonecutter.eval(stonecutter.current.version, "= 1.8.9")
            ) "JAVA_25" else "JAVA_21"
            this.inputs.property("mixin_compat", mixinCompat)
            this.filesMatching("mixins.tgoneconfigv1*.json") {
                filter { line -> line.replace("\"JAVA_21\"", "\"$mixinCompat\"") }
            }
        }

        val minJavaVersion = 21
        val javaVersion = if (
            stonecutter.eval(stonecutter.current.version, ">= 26.1") ||
            stonecutter.eval(stonecutter.current.version, "= 1.8.9")
        ) {
            25
        } else {
            21
        }

        configure<JavaPluginExtension> {
            targetCompatibility = JavaVersion.toVersion(javaVersion)
            sourceCompatibility = JavaVersion.toVersion(minJavaVersion)
        }

        configure<KotlinJvmExtension> {
            jvmToolchain(javaVersion)
        }

        val inCI = providers.environmentVariable("CI").map { it.toBoolean() }.orElse(false).get()

        tasks.withType<JavaCompile>().configureEach {
            if (inCI) return@configureEach
            // standalone compile tasks like compileModMenuApiShimJava have no checkstyle task
            val sourceSet = sourceSets.find { it.compileJavaTaskName == name } ?: return@configureEach
            finalizedBy("checkstyle${sourceSet.name.replaceFirstChar(Char::uppercaseChar)}")
        }

        tasks.withType<KotlinCompile>().configureEach {
            // FixedScrollConfig relies on Compose internals, for which there is no public alternative
            compilerOptions.freeCompilerArgs.add("-Xdont-warn-on-error-suppression")
            compilerOptions.optIn.add("org.tg.tgoneconfig.api.ui.v1.InternalTGOneConfigUiApi")
        }

        tasks.withType<Jar>().configureEach {
            exclude("org/tg/tgoneconfig/test/**")
        }
    }
}

private fun Project.handleApiDep(dependency: String, isMod: Boolean = false, transitive: Boolean = false, bundle: Boolean = true) {
    val dep = dependencies.create(dependency) as ExternalModuleDependency
    handleApiDep(dep, isMod, transitive, bundle)
}

private fun Project.handleApiDep(
    dependency: ExternalModuleDependency,
    isMod: Boolean = false,
    transitive: Boolean = false,
    bundle: Boolean = true,
) {
    handleApiDep(provider { dependency }, isMod, transitive, bundle)
}

@JvmName("handleApiDepBundle")
private fun Project.handleApiDep(
    dependency: Provider<out ExternalModuleDependencyBundle>,
    isMod: Boolean = false,
    transitive: Boolean = false,
    bundle: Boolean = true,
) {
    dependency.get().forEach { handleApiDep(it, isMod, transitive, bundle) }
}

private fun Project.handleApiDep(
    dependency: Provider<out ExternalModuleDependency>,
    isMod: Boolean = false,
    transitive: Boolean = false,
    bundle: Boolean = true,
) {
    dependencies {
        (if (isMod) "modImplementation" else "api")(dependency) {
            isTransitive = transitive
        }
        if (bundle) "bundle"(dependency)
    }
}
