package org.polyfrost.vanillahud

import net.fabricmc.api.ClientModInitializer
//? if > 1.8.9 {
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
//?} else {
/*import org.polyfrost.oneconfig.api.event.v1.events.InitializationEvent
import org.polyfrost.oneconfig.api.event.v1.events.TickEvent
import org.polyfrost.oneconfig.api.event.v1.invoke.EventHandler
*///?}
import org.polyfrost.oneconfig.api.event.v1.EventManager
import org.polyfrost.oneconfig.api.event.v1.events.WorldEvent
import java.util.function.Consumer
import org.polyfrost.oneconfig.api.hud.v1.HudGroups
import org.polyfrost.oneconfig.api.hud.v1.HudManager
import org.polyfrost.vanillahud.compat.HudElementCompat
import org.polyfrost.vanillahud.hud.AirHud
import org.polyfrost.vanillahud.hud.ArmorHud
import org.polyfrost.vanillahud.hud.ExperienceBarHud
import org.polyfrost.vanillahud.hud.ExperienceLevelHud
import org.polyfrost.vanillahud.hud.HealthHud
import org.polyfrost.vanillahud.hud.HotbarHud
import org.polyfrost.vanillahud.hud.Huds
import org.polyfrost.vanillahud.hud.HungerHud
import org.polyfrost.vanillahud.hud.SubtitleHud
import org.polyfrost.vanillahud.hud.TitleHud
import org.polyfrost.vanillahud.hud.VanillaHud
import org.polyfrost.vanillahud.render.HudCapture
import org.polyfrost.vanillahud.util.ForceDefaultPosition
import org.polyfrost.vanillahud.util.HudConfigMigrator

object VanillaHUDClient : ClientModInitializer {
    override fun onInitializeClient() {
        // before OneConfig loads the HUDs, or it saves what it read back over the migrated files
        HudConfigMigrator.migrate()

        //? if = 1.8.9 {
        /*// 1.8.9 runs entrypoints before Minecraft.init, so the HUDs cannot be built yet: the font
        // and the language files they measure against do not exist. Defer to the end of init, at
        // the lowest priority so OneConfig's own setup has already run.
        object : EventHandler<InitializationEvent>() {
            override fun handle(event: InitializationEvent): Boolean {
                setup()
                return true
            }

            override fun getEventClass(): Class<InitializationEvent> = InitializationEvent::class.java

            override fun getPriority(): Int = Int.MIN_VALUE
        }.register()
        *///?} else
        setup()
    }

    private fun setup() {
        Huds.all.forEach {
            HudManager.register(it, "vanillahud", "/assets/vanillahud/vanillahud_dark.svg")
        }

        HudGroups.registerDefault(
            "vanillahud-hotbar", "Hotbar",
            HotbarHud::class.java, HealthHud::class.java, ArmorHud::class.java, HungerHud::class.java, AirHud::class.java,
            ExperienceBarHud::class.java, ExperienceLevelHud::class.java,
        )
        HudGroups.registerDefault("vanillahud-title", "Title & Subtitle", TitleHud::class.java, SubtitleHud::class.java)

        //? if > 1.8.9 {
        ClientTickEvents.END_CLIENT_TICK.register(ClientTickEvents.EndTick { onTick() })
        //?} else {
        /*// same per tick refresh the newer versions get from the Fabric end tick event: without it
        // the editor previews keep whatever they measured when the editor opened
        EventManager.register(TickEvent.End::class.java, Consumer { onTick() })
        *///?}

        // close every icon, or animated ones keep the atlas redrawing even after the world unloads
        EventManager.register(WorldEvent.Unload::class.java, Consumer { HudCapture.closeIcons() })

        HudElementCompat.init()
    }

    private fun onTick() {
        ForceDefaultPosition.tick()
        VanillaHud.markRefreshDue()
        if (HudManager.isEditing) VanillaHud.refreshAll()
    }
}
