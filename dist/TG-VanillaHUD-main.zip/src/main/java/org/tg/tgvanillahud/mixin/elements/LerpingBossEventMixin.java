package org.tg.tgvanillahud.mixin.elements;

//? if > 1.8.9 {
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.gui.components.LerpingBossEvent;
import org.tg.tgvanillahud.hud.BossBarHud;
import org.tg.tgvanillahud.hud.Huds;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LerpingBossEvent.class)
public class LerpingBossEventMixin {
    @Shadow
    protected float targetPercent;

    @Inject(method = "getProgress", at = @At("HEAD"), cancellable = true)
    private void tgvanillahud$instant(CallbackInfoReturnable<Float> cir) {
        BossBarHud hud = Huds.INSTANCE.getBossBar();
        if (!hud.isDrawnAsVanilla() && !hud.getSmoothHealth()) cir.setReturnValue(targetPercent);
    }

    @ModifyExpressionValue(method = "getProgress", at = @At(value = "CONSTANT", args = "floatValue=100.0f"))
    private float tgvanillahud$lerpSpeed(float original) {
        BossBarHud hud = Huds.INSTANCE.getBossBar();
        return hud.isDrawnAsVanilla() ? original : hud.getLerpSpeed();
    }
}
//?} else {
/*// 1.8.9 has no lerping boss event, BossBarHud smooths the health itself
import net.minecraft.client.gui.GameGui;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(GameGui.class)
public class LerpingBossEventMixin {
}
*///?}
