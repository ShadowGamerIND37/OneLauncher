package org.polyfrost.oneconfig.internal.mixin.compat.toggle;

import org.polyfrost.oneconfig.api.toggle.v1.ModToggle;
import org.polyfrost.oneconfig.api.ui.v1.ModToggles;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "org.codeberg.chromatic.vignettetweaks.config.VignetteConfig$Hunger", remap = false)
public class Mixin_Toggle_VignetteHunger {
    @Unique
    private static final ModToggle oneconfig$toggle = ModToggles.handle("vignettetweaks");

    @Inject(method = "evaluate", at = @At("HEAD"), cancellable = true, require = 0)
    private static void oneconfig$noTint(CallbackInfoReturnable<Object> cir) {
        if (!oneconfig$toggle.isEnabled()) cir.setReturnValue(null);
    }
}
