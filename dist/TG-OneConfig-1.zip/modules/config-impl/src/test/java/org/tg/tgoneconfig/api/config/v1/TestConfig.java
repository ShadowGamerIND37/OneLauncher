/*
 * This file is part of TGOneConfig.
 * TGOneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 TG.
 *   <https://github.com/ShadowGamerIND37> <https://github.com/TG/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   TGOneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to TGOneConfig, as published by TG,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to TGOneConfig, as published by TG. If not, see
 * <https://github.com/ShadowGamerIND37/legal/tgoneconfig/additional-terms>
 */

package org.tg.tgoneconfig.api.config.v1;

import org.tg.tgoneconfig.api.config.v1.annotations.Accordion;
import org.tg.tgoneconfig.api.config.v1.annotations.Button;
import org.tg.tgoneconfig.api.config.v1.annotations.Color;
import org.tg.tgoneconfig.api.config.v1.annotations.DependsOn;
import org.tg.tgoneconfig.api.config.v1.annotations.Dropdown;
import org.tg.tgoneconfig.api.config.v1.annotations.Number;
import org.tg.tgoneconfig.api.config.v1.annotations.RadioButton;
import org.tg.tgoneconfig.api.config.v1.annotations.Slider;
import org.tg.tgoneconfig.api.config.v1.annotations.Switch;
import org.tg.tgoneconfig.api.config.v1.annotations.Text;

import java.util.Arrays;
import java.util.List;

@SuppressWarnings("unused")
public class TestConfig extends Config {

    @Switch(
            title = "Chicken",
            subcategory = "Chick"
    )
    public static boolean chicken = true;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do", subcategory = "Chick")
    public static boolean cow = false;
    @Dropdown(title = "drop")
    public static int[] dropint = new int[]{23, 2, 24};
    @Dropdown(title = "drop")
    public static String[] dropstr = new String[]{"23", "2", "24"};
    @Dropdown(title = "drop")
    public static boolean[] dropbool = new boolean[]{true, false, true};
    @Dropdown(title = "drop")
    public static float[] dropfloat = new float[]{23f, 2f, 24f};
    @Dropdown(title = "drop")
    public static double[] dropdouble = new double[]{23d, 2d, 24d};
    @Dropdown(title = "drop")
    public static long[] droplong = new long[]{23L, 2L, 24L};
    @Dropdown(title = "drop")
    public static short[] dropshort = new short[]{23, 2, 24};
    @Dropdown(title = "drop")
    public static Boolean[] dropboolean = new Boolean[]{true, false, true};
    @Number(title = "number", unit = "px", category = "bob")
    public static int number = 50;
    @Slider(title = "Slide", min = 10f, max = 110f, icon = "assets/tgoneconfig/ico/paintbrush.svg", description = "I do sliding", category = "bob")
    public static float p = 50f;
    @Text(title = "Text")
    public static String text = "Hello world!";
    @Dropdown(title = "A dropdown", description = "I do dropping (on Tuesdays)", options = {"A", "B", "C", "SADW", "AS", "FGAW", "ASDA", "ASDFHUA", "ASHDUIW", "HAWSUDIHWAUI", "&SHAJD", "AWSHUID"})
    public static int i = 0;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow2 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow3 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow4 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow5 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean acow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean scow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cgow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c2ow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c3ow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c4ow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c5ow = false;
    @RadioButton(title = "radio", description = "send help", options = {"Option A", "Option B", "Option C"})
    public static int radio = 0;
    @Switch(title = "t")
    public boolean added = false;
    @Dropdown(title = "d")
    public List<Integer> intList = Arrays.asList(32, 54, 2);
    @Color(title = "color", category = "bob")
    int color = 0xFFFF0064;

    public TestConfig() {
        super("test_mod.json", "Test Mod", Category.QOL);
    }

    @Override
    public void initialize(boolean byConfigManager) {
        super.initialize(byConfigManager);
    }

    @Button(title = "Test")
    private static void testBtn() {
    }

    @Accordion(title = "an accordion", description = "AAAAAAAAAAAAAAAAAAAAAAAAAAH", index = 4)
    public static class AAAAA {
        @Text(title = "Text")
        public static String text = "Hello world!";

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        @DependsOn("cow2")
        public static boolean cbow = false;

        @RadioButton(title = "radio when me when me when me:", description = "send help", options = {"Option A", "Option B", "Option C"})
        public static int radio2 = 0;

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        public static boolean cbo2w = false;

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        public static boolean cbogw = false;
    }
}
