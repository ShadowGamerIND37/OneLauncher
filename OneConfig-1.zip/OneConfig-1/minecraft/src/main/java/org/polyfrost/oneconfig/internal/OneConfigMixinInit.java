/*
 * This file is part of OneConfig.
 * OneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 Polyfrost.
 *   <https://polyfrost.org> <https://github.com/Polyfrost/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   OneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to OneConfig, as published by Polyfrost,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to OneConfig, as published by Polyfrost. If not, see
 * <https://polyfrost.org/legal/oneconfig/additional-terms>
 */

package org.polyfrost.oneconfig.internal;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.polyfrost.oneconfig.internal.compat.toggle.ToggleHooks;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

//? if moul_compat {
import kotlin.Unit;
import org.polyfrost.oneconfig.internal.generated.RelocatedMixins;
//?}

public class OneConfigMixinInit implements IMixinConfigPlugin {

    @Override
    public void onLoad(String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (ToggleHooks.isToggleMixin(mixinClassName)) return ToggleHooks.fits(targetClassName, mixinClassName);
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        List<String> mixins = new ArrayList<>();

        //? if = 1.8.9 {
        /*mixins.add("command.Mixin_LegacyChatCompletion");
        mixins.add("fixes.Mixin_RememberUnknownOptions");
        mixins.add("keybind.Mixin_LegacySharedKeyCodes");
        *///?}

        //? moul_compat {
        RelocatedMixins.INSTANCE.register(e -> {
            mixins.add(e);
            return Unit.INSTANCE;
        });
        //? }
        //? moul_compat {
        mixins.add("compat.moulconfig.Mixin_MCConfigEditorIntegration_Firmament");
        // unrelocated targets, e.g. SoftConfig in Skysoft < 0.1.30
        mixins.add("compat.moulconfig.Mixin_ConfigProcessorDriver");
        mixins.add("compat.moulconfig.Mixin_MoulConfigProcessor");
        mixins.add("compat.moulconfig.Mixin_MoulConfigEditor");
        mixins.add("compat.moulconfig.Mixin_PropertyImpl");
        mixins.add("compat.moulconfig.Mixin_GuiOptionEditorSlider");
        mixins.add("compat.moulconfig.Mixin_GuiOptionEditorDropdown");
        //? }

        //? dandelion_compat
        //mixins.add("compat.DandelionScreenImplMixin");

        //? odin_compat
        //mixins.add("compat.odin.Mixin_OdinModuleManager");

        //? rconfig_compat
        //mixins.add("compat.rconfig.Mixin_Configurations");

        //? osl_config_compat
        //mixins.add("compat.osl.Mixin_OslConfigManager");

        mixins.add("Mixin_SimpleReloadInstance");
        //? if > 1.8.9
        mixins.add("Mixin_VersionedResourcePacks");
        //? if > 1.8.9
        mixins.add("fixes.Mixin_SkipMalformedOptions");
        //? if >= 26.3
        mixins.add("fixes.Mixin_LegacyVideoModeFormat");
        //? if >= 26.3
        mixins.add("fixes.Mixin_MonitorNearestRefresh");
        //? if >= 26.3
        mixins.add("fixes.Mixin_LegacyExclusiveFullscreen");
        //? if > 1.8.9
        mixins.add("Mixin_CommunityTranslations");
        //? if = 1.8.9
        //mixins.add("Mixin_LegacyCommunityTranslations");
        //? yacl_compat
        mixins.add("compat.yacl.Mixin_YetAnotherConfigLib_Builder");

        //? clothconfig_compat
        mixins.add("compat.cloth.Mixin_ConfigBuilderImpl");

        //? midnightlib_compat
        mixins.add("compat.midnightlib.Mixin_MidnightConfig");
        //? midnightlib_compat
        mixins.add("compat.midnightlib.SliderButtonAccessor");

        //? walksylib_compat
        mixins.add("compat.walksylib.Mixin_WalksyLib_ModEntryPointList");

        //? tr7zw_compat
        mixins.add("compat.tr7zw.Mixin_AbstractConfigScreen");

        //? ukulib_compat
        mixins.add("compat.ukulib.Mixin_BaseConfigScreen");

        //? axolotlclient_config_compat
        mixins.add("compat.axolotlclient.Mixin_AxolotlClientConfigImpl");

        //? mlib_compat
        //mixins.add("compat.mlib.Mixin_MlibOverlays");

        //? skyblocker_compat {
        /*Boolean skyblockerSingleton = declaresStaticMethod("de.hysky.skyblocker.skyblock.fancybars.FancyStatusBars", "initStatic");
        if (skyblockerSingleton != null) {
            mixins.add(skyblockerSingleton
                    ? "compat.skyblocker.Mixin_SkyblockerFancyStatusBarsInstance"
                    : "compat.skyblocker.Mixin_SkyblockerFancyStatusBarsStatic");
        }
        mixins.add("compat.skyblocker.Mixin_SkyblockerWidgetManager");
        mixins.add("compat.skyblocker.Mixin_SkyblockerLayerBuilder");
        *///? }

        //? stella_compat
        //mixins.add("compat.stella.Mixin_Stella");

        //? if skyblock {
        mixins.add("compat.skyhanni.Mixin_SkyHanniRenderData");
        mixins.add("compat.firmament.Mixin_FirmamentHudMeta");
        //?}
        // Firmament has no stable release for 26.2 yet
        //? skyblock && < 26.2
        //mixins.add("compat.firmament.Mixin_FirmamentContentCapture");

        //? if > 1.8.9
        mixins.add("compat.armorhud.Mixin_ArmorHudWidgetShown");

        // master switches for mods that do not have one, see ModGates
        mixins.addAll(ToggleHooks.mixins());

        //? modmenu_compat
        mixins.add("compat.Mixin_ModMenu");

        mixins.add("events.Mixin_ScreenOpenEvent_Fabric");

        mixins.add("events.Mixin_ModernWindowFocusEvent");

        mixins.add("render.Mixin_HudFrameState");
        mixins.add("render.Mixin_VanillaHudElements");
        //? if > 1.8.9 {
        mixins.add("render.HudSampleAccessor");
        mixins.add("render.BossHealthOverlayAccessor");
        //?}
        //? if > 1.8.9 && < 1.21.8
        //mixins.add("render.Mixin_VanillaHudFootprintImmediate");
        //? if = 1.8.9 {
        /*mixins.add("render.LegacyHudSampleAccessor");
        mixins.add("render.Mixin_VanillaHudFootprintLegacyGuiElement");
        mixins.add("render.Mixin_VanillaHudFootprintLegacyTextRenderer");
        mixins.add("render.Mixin_VanillaHudFootprintLegacyItemRenderer");
        mixins.add("render.Mixin_VanillaHudFootprintLegacyGameGui");
        *///?}
        //? if >= 1.21.8 {
        mixins.add("render.Mixin_VanillaHudFootprint");


        //? }

        //? if >= 1.21.10 {
        mixins.add("keybind.Mixin_KeybindCategoryLabel");
        //?} elif > 1.8.9
        //mixins.add("keybind.KeyMappingCategoryAccessor");

        mixins.add("keybind.Mixin_OneConfigKeybindRebind");
        mixins.add("keybind.Mixin_KeyMappingResetDetect");
        mixins.add("keybind.Mixin_OptionsSaveDetect");
        mixins.add("keybind.Mixin_OptionsSkipMirrors");
        //? if = 1.8.9
        //mixins.add("keybind.Mixin_KeyBindsListRows");

        {
            Logger logger = LogManager.getLogger(OneConfigMixinInit.class);
            logger.info("Loaded {} non-common Mixins", mixins.size());

            for (int i = 0; i < mixins.size(); i += 5) {
                int end = Math.min(i + 5, mixins.size());
                List<String> batch = mixins.subList(i, end);
                logger.info("Loaded Mixins: {}", String.join(", ", batch));
            }
        }

        return mixins;
    }

    private static Boolean declaresStaticMethod(String className, String methodName) {
        try (InputStream in = OneConfigMixinInit.class.getClassLoader()
                .getResourceAsStream(className.replace('.', '/') + ".class")) {
            if (in == null) return null;
            ClassNode node = new ClassNode();
            new ClassReader(in).accept(node, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
            for (MethodNode method : node.methods) {
                if (method.name.equals(methodName) && (method.access & Opcodes.ACC_STATIC) != 0) return Boolean.TRUE;
            }
            return Boolean.FALSE;
        } catch (Throwable t) {
            LogManager.getLogger(OneConfigMixinInit.class)
                    .warn("could not read {} to pick a mixin shape, skipping the mixins that depend on it", className, t);
            return null;
        }
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

}
