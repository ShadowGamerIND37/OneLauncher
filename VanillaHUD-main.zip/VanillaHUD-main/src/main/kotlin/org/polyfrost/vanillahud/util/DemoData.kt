package org.polyfrost.vanillahud.util

//? if > 1.8.9 {
import net.minecraft.ChatFormatting
import net.minecraft.client.gui.components.LerpingBossEvent
import net.minecraft.client.resources.sounds.SimpleSoundInstance
import net.minecraft.client.resources.sounds.SoundInstance
import net.minecraft.client.sounds.WeighedSoundEvents
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvents
import net.minecraft.sounds.SoundSource
import net.minecraft.network.chat.Component
import net.minecraft.world.BossEvent
import net.minecraft.world.effect.MobEffectInstance
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.scores.Objective
import net.minecraft.world.scores.ScoreHolder
import net.minecraft.world.phys.Vec3
import net.minecraft.world.scores.Scoreboard
import net.minecraft.world.scores.criteria.ObjectiveCriteria
import java.util.UUID

object DemoData {
    private var scoreboardObjective: Objective? = null

    private val subtitleLines = listOf(
        "Skeleton rattles" to 1,
        "Zombie groans" to -1,
        "Footsteps" to 0,
        "Squid swims" to 1,
        "Splashing" to -1,
    )

    class DemoSubtitle(val sound: SoundInstance, val event: WeighedSoundEvents, val range: Float)

    @JvmStatic
    fun demoSubtitles(pos: Vec3, forward: Vec3, right: Vec3): List<DemoSubtitle> =
        subtitleLines.map { (name, dir) ->
            val location = when (dir) {
                1 -> pos.add(forward.scale(8.0))
                -1 -> pos.subtract(forward.scale(8.0))
                else -> pos.add(right.scale(8.0))
            }
            val sound = SimpleSoundInstance(
                SoundEvents.UI_BUTTON_CLICK.value(),
                SoundSource.MASTER,
                1f,
                1f,
                SoundInstance.createUnseededRandom(),
                location.x,
                location.y,
                location.z,
            )
            val event = WeighedSoundEvents(Identifier.withDefaultNamespace("vanillahud_demo"), name)
            DemoSubtitle(sound, event, Float.POSITIVE_INFINITY)
        }

    @JvmStatic
    fun demoScoreboardObjective(): Objective? {
        scoreboardObjective?.let { return it }
        return try {
            val scoreboard = Scoreboard()
            val objective = scoreboard.addObjective(
                "vanillahud_demo",
                ObjectiveCriteria.DUMMY,
                Component.literal("VanillaHUD").withStyle(ChatFormatting.YELLOW),
                ObjectiveCriteria.RenderType.INTEGER,
                false,
                null
            )
            putScore(scoreboard, objective, Component.literal("Kills").withStyle(ChatFormatting.GREEN), 7)
            putScore(scoreboard, objective, Component.literal("Deaths").withStyle(ChatFormatting.RED), 2)
            putScore(scoreboard, objective, Component.literal("K/D").withStyle(ChatFormatting.AQUA), 3)
            putScore(scoreboard, objective, Component.literal("Coins").withStyle(ChatFormatting.GOLD), 1337)
            putScore(scoreboard, objective, Component.literal("Rank").withStyle(ChatFormatting.LIGHT_PURPLE), 1)
            scoreboardObjective = objective
            objective
        } catch (_: Throwable) {
            null
        }
    }

    private fun putScore(scoreboard: Scoreboard, objective: Objective, name: Component, value: Int) {
        val holder = ScoreHolder.forNameOnly(name.string)
        val score = scoreboard.getOrCreatePlayerScore(holder, objective)
        score.set(value)
        score.display(name)
    }

    private var effects: List<MobEffectInstance>? = null

    @JvmStatic
    fun demoEffects(): List<MobEffectInstance> {
        effects?.let { return it }
        return try {
            val holders = listOf(
                MobEffects.REGENERATION,
                MobEffects.FIRE_RESISTANCE,
                MobEffects.NIGHT_VISION,
                MobEffects.WATER_BREATHING,
                MobEffects.POISON,
            )
            val list = holders.map { MobEffectInstance(it, 999999, 0, false, true, true) }
            effects = list
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private val hotbar by lazy {
        listOf(Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.BOW, Items.APPLE).map { ItemStack(it) }
    }

    @JvmStatic
    fun demoHotbarItem(slot: Int): ItemStack = hotbar.getOrElse(slot) { ItemStack.EMPTY }

    @JvmStatic
    fun demoBossEvents(): List<LerpingBossEvent> = listOf(
        LerpingBossEvent(
            UUID.fromString("00000000-0000-0000-0000-000000000001"),
            Component.literal("Boss Bar"),
            0.67f,
            BossEvent.BossBarColor.PINK,
            BossEvent.BossBarOverlay.PROGRESS,
            false,
            false,
            false
        )
    )
}
//?} else {
/*import net.minecraft.item.Items
import net.minecraft.scoreboard.Scoreboard
import net.minecraft.scoreboard.ScoreboardObjective
import net.minecraft.scoreboard.criterion.ScoreboardCriterion
import net.minecraft.text.LiteralText
import net.minecraft.text.Text
import net.minecraft.world.item.ItemStack

// 1.8.9 has no subtitles and no HUD status effects, so only the scoreboard and the boss bar
// have anything to preview. Its scoreboard is addressed by owner name and its display names
// are legacy formatted strings rather than components.
object DemoData {
    private const val YELLOW = "\u00a7e"
    private const val GREEN = "\u00a7a"
    private const val RED = "\u00a7c"
    private const val AQUA = "\u00a7b"
    private const val GOLD = "\u00a76"
    private const val LIGHT_PURPLE = "\u00a7d"

    private var scoreboardObjective: ScoreboardObjective? = null

    @JvmStatic
    fun demoScoreboardObjective(): ScoreboardObjective? {
        scoreboardObjective?.let { return it }
        return try {
            val scoreboard = Scoreboard()
            val objective = scoreboard.createObjective("vanillahud_demo", ScoreboardCriterion.DUMMY)
            objective.displayName = YELLOW + "VanillaHUD"
            putScore(scoreboard, objective, GREEN + "Kills", 7)
            putScore(scoreboard, objective, RED + "Deaths", 2)
            putScore(scoreboard, objective, AQUA + "K/D", 3)
            putScore(scoreboard, objective, GOLD + "Coins", 1337)
            putScore(scoreboard, objective, LIGHT_PURPLE + "Rank", 1)
            scoreboardObjective = objective
            objective
        } catch (_: Throwable) {
            null
        }
    }

    private fun putScore(scoreboard: Scoreboard, objective: ScoreboardObjective, name: String, value: Int) {
        scoreboard.getScore(name, objective).set(value)
    }

    private val hotbar by lazy {
        arrayOfNulls<ItemStack>(9).also { slots ->
            listOf(Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.BOW, Items.APPLE)
                .forEachIndexed { i, item -> slots[i] = ItemStack(item) }
        }
    }

    @JvmStatic
    fun demoHotbar(): Array<ItemStack?> = hotbar

    /** the 1.8.9 boss bar is a single bar of static state, so the preview is just its name */
    @JvmStatic
    fun demoBossName(): String = "Boss Bar"

    // stable instances so the measure cache and the renderer agree on the previewed header
    private val tabHeader: Text = LiteralText("Tab List")
    private val tabFooter: Text = LiteralText("VanillaHUD")

    @JvmStatic
    fun demoTabHeader(): Text = tabHeader

    @JvmStatic
    fun demoTabFooter(): Text = tabFooter
}
*///?}
