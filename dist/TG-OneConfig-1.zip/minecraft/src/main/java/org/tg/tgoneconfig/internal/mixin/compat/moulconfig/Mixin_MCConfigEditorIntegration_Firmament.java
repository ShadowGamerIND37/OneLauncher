package org.tg.tgoneconfig.internal.mixin.compat.moulconfig;

//? moul_compat {
import java.lang.reflect.Field;
import java.util.Collection;
import org.tg.tgoneconfig.internal.compat.MoulConfigDispatch;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "moe.nea.firmament.compat.moulconfig.MCConfigEditorIntegration", remap = false)
public class Mixin_MCConfigEditorIntegration_Firmament {
    @Inject(method = "<init>()V", at = @At("TAIL"), require = 0)
    private void tgoneconfig$onInit(CallbackInfo ci) {
        try {
            Field categoriesField = this.getClass().getDeclaredField("categories");
            Field configField = this.getClass().getDeclaredField("configObject");
            categoriesField.setAccessible(true);
            configField.setAccessible(true);

            Object categoriesValue = categoriesField.get(this);
            Object configValue = configField.get(this);

            if (categoriesValue instanceof Collection<?> && configValue != null) {
                MoulConfigDispatch.parseMoulconfigFromUnknownEditor((Collection<?>) categoriesValue, configValue);
            }
        } catch (Throwable ignored) {}
    }
}
//? }