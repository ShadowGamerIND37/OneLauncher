package org.tg.tgoneconfig.internal.ui.keybind

import com.mojang.blaze3d.platform.InputConstants
import java.nio.file.Files
import java.nio.file.Path
import java.util.IdentityHashMap
import java.util.function.Consumer
import java.util.function.Supplier
import net.minecraft.client.KeyMapping
import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component
import org.tg.tgoneconfig.api.config.v1.Properties
import org.tg.tgoneconfig.api.config.v1.Property
import org.tg.tgoneconfig.api.config.v1.Visualizer
import org.tg.tgoneconfig.api.platform.v1.ModInfo
import org.tg.tgoneconfig.api.ui.v1.keybind.KeyModifiers
import org.tg.tgoneconfig.api.ui.v1.keybind.TGOneConfigKeybind
import org.tg.tgoneconfig.api.ui.v1.keybind.internal.MinecraftKeybindBridgeImpl
import org.tg.tgoneconfig.api.ui.v1.keybind.internal.MinecraftKeybindCodec

//? if >= 26.3 {
import net.minecraft.server.packs.FixedPathPackResources
//?}

// still null early in startup, whatever the nullness annotations on newer versions claim
internal fun minecraftOrNull(): Minecraft? = Minecraft.getInstance()

object MinecraftKeybindProvider : KeybindGroupProvider {
    private val properties = IdentityHashMap<KeyMapping, Property<TGOneConfigKeybind>>()
    private val modIconCache = mutableMapOf<String, String?>()

    private data class MinecraftKeybindGroup(
        val category: String,
        val ownerId: String,
        val title: String,
        val icon: String?,
    )

    private data class DiscoveredKeybind(
        val group: MinecraftKeybindGroup,
        val entry: KeybindEntry,
    )

    override fun groups(): List<KeybindGroup> {
        val minecraft = Minecraft.getInstance()
        val modsById = ModInfo.loadedMods.associateBy { it.id.lowercase() }
        val entriesByGroup = minecraft.options.keyMappings
            .asSequence()
            .filterNot { isTGOneConfigMirror(it) }
            .map { mapping ->
                val owner = ownerMod(mapping, modsById)
                val category = categoryLabel(mapping)
                DiscoveredKeybind(
                    group = MinecraftKeybindGroup(
                        category = category,
                        ownerId = owner?.id ?: "unknown",
                        title = groupTitle(category, owner),
                        icon = modIcon(owner) ?: minecraftIcon(),
                    ),
                    entry = KeybindEntry(
                        path = "minecraft.${mapping.name}",
                        category = "Minecraft",
                        subcategory = "Controls",
                        prop = properties.getOrPut(mapping) { propertyFor(mapping) },
                    ),
                )
            }
            .groupBy { it.group }

        return entriesByGroup
            .toSortedMap(compareBy<MinecraftKeybindGroup> { it.category }.thenBy { it.ownerId })
            .mapNotNull { (group, discovered) ->
                val entries = discovered.map { it.entry }.sortedBy { it.prop.title?.toString() ?: it.path }
                if (entries.isEmpty()) return@mapNotNull null
                KeybindGroup(
                    modId = "minecraft-keybinds.${group.ownerId}.${sanitizeId(group.category)}",
                    modTitle = group.title,
                    modIcon = group.icon,
                    entries = entries,
                )
            }
    }

    fun managedMappings(): List<KeyMapping> {
        val options = minecraftOrNull()?.options ?: return emptyList()
        return options.keyMappings.filterNot { isTGOneConfigMirror(it) }
    }

    private fun propertyFor(mapping: KeyMapping): Property<TGOneConfigKeybind> {
        val prop = Properties.functional(
            Supplier { mapping.toTGOneConfigKeybind() },
            Consumer { keybind -> mapping.applyTGOneConfigKeybind(keybind) },
            "minecraft.${mapping.name}",
            translate(mapping.name),
            null,
            TGOneConfigKeybind::class.java,
        )
        prop.addMetadata("visualizer", Visualizer.KeybindVisualizer::class.java)
        prop.addMetadata("singleKey", true)
        prop.addMetadata("default", mapping.defaultKey.toTGOneConfigKeybind())
        prop.addMetadata("category", categoryLabel(mapping))
        prop.addMetadata("subcategory", "Minecraft Controls")
        return prop
    }

    private fun ownerMod(mapping: KeyMapping, modsById: Map<String, ModInfo>): ModInfo? {
        return ownerCandidates(mapping.name)
            .map { it.lowercase() }
            .firstNotNullOfOrNull { modsById[it] }
    }

    private fun ownerCandidates(keyName: String): Sequence<String> = sequence {
        if (':' in keyName) {
            val beforeNamespaceSeparator = keyName.substringBefore(':')
            yield(beforeNamespaceSeparator.substringAfterLast('.'))
            yield(beforeNamespaceSeparator)
        }
        if (keyName.startsWith("key.")) {
            yield(keyName.removePrefix("key.").substringBefore('.').substringBefore(':'))
        }
        yield(keyName.substringBefore('.'))
    }

    private fun modIcon(owner: ModInfo?): String? =
        owner?.let { modIconCache.getOrPut(it.id) { it.extractIconFile() } }

    private const val MINECRAFT_ICON_FALLBACK = "/assets/tgoneconfig/images/minecraft-light.svg"
    private var minecraftIconResolved = false
    private var minecraftIconPath: String? = null

    private fun minecraftIcon(): String {
        if (!minecraftIconResolved) {
            minecraftIconPath = extractMinecraftIcon() ?: MINECRAFT_ICON_FALLBACK
            minecraftIconResolved = true
        }
        return minecraftIconPath ?: MINECRAFT_ICON_FALLBACK
    }

    private fun extractMinecraftIcon(): String? = runCatching {
        //? if >= 26.3 {
        val vanilla = Minecraft.getInstance().vanillaPackResources.fullResources()
                as? FixedPathPackResources ?: return@runCatching null
        //?} else
        //val vanilla = Minecraft.getInstance().vanillaPackResources
        val bytes = listOf(128, 256, 64, 32).firstNotNullOfOrNull { size ->
            runCatching {
                val supplier = vanilla.getRootResource("icons", "icon_${size}x$size.png") ?: return@runCatching null
                supplier.get().use { it.readBytes() }
            }.getOrNull()
        } ?: return@runCatching null
        val dir = Files.createDirectories(
            Path.of(System.getProperty("java.io.tmpdir"), "tgoneconfig-modicons")
        )
        val dest = dir.resolve("minecraft.png")
        Files.write(dest, bytes)
        dest.toAbsolutePath().toString()
    }.getOrNull()

    private fun groupTitle(category: String, owner: ModInfo?): String {
        val ownerName = owner?.name?.takeUnless { it.isBlank() } ?: return category
        if (category.contains(ownerName, ignoreCase = true)) return category
        return "$category ($ownerName)"
    }

    private fun sanitizeId(value: String): String {
        val lowered = value.lowercase()
        val sanitized = lowered.replace(Regex("[^a-z0-9._-]"), "_")
        if (sanitized == lowered) return sanitized
        return sanitized + "-" + Integer.toHexString(lowered.hashCode())
    }

    private fun KeyMapping.toTGOneConfigKeybind(): TGOneConfigKeybind {
        val key = runCatching { InputConstants.getKey(saveString()) }.getOrDefault(InputConstants.UNKNOWN)
        return key.toTGOneConfigKeybind()
    }

    private fun InputConstants.Key.toTGOneConfigKeybind(): TGOneConfigKeybind {
        return when (type) {
            //~ if sdl 'Type.KEYSYM' -> 'Type.KEYBOARD'
            InputConstants.Type.KEYBOARD if value > 0 ->
                TGOneConfigKeybind(intArrayOf(value), null, KeyModifiers.NONE, 0L) { true }
            //~ if sdl 'value >= 0' -> 'value > 0'
            InputConstants.Type.MOUSE if value > 0 ->
                TGOneConfigKeybind(null, intArrayOf(value), KeyModifiers.NONE, 0L) { true }
            else -> TGOneConfigKeybind(null, null, KeyModifiers.NONE, 0L) { true }
        }
    }

    private fun KeyMapping.applyTGOneConfigKeybind(keybind: TGOneConfigKeybind?) {
        val mouseButtons = keybind?.mouseBtns
        val keyCodes = keybind?.keyCodes
        val key = when {
            keybind == null || !keybind.isBound -> InputConstants.UNKNOWN
            //~ if sdl 'it >= 0' -> 'it > 0'
            mouseButtons?.firstOrNull { it > 0 } != null -> MinecraftKeybindCodec.mouse(mouseButtons.first { it > 0 })
            keyCodes?.firstOrNull { it > 0 } != null -> MinecraftKeybindCodec.keysym(keyCodes.first { it > 0 })
            else -> InputConstants.UNKNOWN
        }
        setKey(key)
        KeyMapping.resetMapping()
        Minecraft.getInstance().options.save()
    }

    private fun categoryLabel(mapping: KeyMapping): String {
        //? if >= 1.21.10 {
        return runCatching { mapping.category.label().string }.getOrNull()
            ?.takeUnless { it.isBlank() }
            ?: mapping.category.toString()
        //?} else {
        /*return translate(mapping.category)
        *///?}
    }

    private fun translate(key: String): String {
        val translated = runCatching { Component.translatable(key).string }.getOrNull()
        return translated?.takeUnless { it == key || it.isBlank() } ?: key
    }

    private fun isTGOneConfigMirror(mapping: KeyMapping): Boolean =
        MinecraftKeybindBridgeImpl.instance()?.bindFor(mapping) != null
}
