package org.tg.tgoneconfig.internal.mixin.keybind;

//? if < 1.21.10 && > 1.8.9 {
/*import java.util.Map;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(KeyMapping.class)
public interface KeyMappingCategoryAccessor {
    @Accessor("CATEGORY_SORT_ORDER")
    static Map<String, Integer> tgoneconfig$categorySortOrder() {
        throw new AssertionError();
    }
}
*///?}
