plugins {
    id("oneconfig-setup")
}
