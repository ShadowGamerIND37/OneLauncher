/*
 * This file is part of OneConfig.
 * OneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 Polyfrost.
 *   <https://polyfrost.org> <https://github.com/Polyfrost/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   OneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to OneConfig, as published by Polyfrost,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to OneConfig, as published by Polyfrost. If not, see
 * <https://polyfrost.org/legal/oneconfig/additional-terms>
 */

package org.polyfrost.oneconfig.test;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.function.Consumer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.polyfrost.oneconfig.api.config.v1.Config;
import org.polyfrost.oneconfig.api.config.v1.Property;
import org.polyfrost.oneconfig.api.config.v1.ValueFormatter;
import org.polyfrost.oneconfig.api.config.v1.annotations.*;
import org.polyfrost.oneconfig.api.config.v1.annotations.Number;
import org.polyfrost.oneconfig.api.notifications.v1.Notifications;
import org.polyfrost.oneconfig.api.platform.v1.Platform;
import org.polyfrost.oneconfig.api.ui.v1.keybind.KeybindHelper;
import org.polyfrost.oneconfig.api.ui.v1.keybind.OneConfigKeybind;

@SuppressWarnings("unused")
public final class TestConfig_Test extends Config {
    private static final Logger LOGGER = LogManager.getLogger("OneConfig/TestMod");
    private static TestConfig_Test INSTANCE;

    @MasterToggle
    public static boolean enabled = true;
    @Switch(
            title = "Chicken",
            subcategory = "Chick"
    )
    public static boolean chicken = true;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do", subcategory = "Chick")
    public static boolean cow = false;
    @Checkbox(title = "checkbox", description = "I do checkboxes", category = "bob")
    public static boolean checkbox = false;
    @Number(title = "number", unit = "px", category = "bob")
    public static int number = 50;

    @Keybind(title = "keybinding", description = "please send help")
    OneConfigKeybind bind0 = KeybindHelper.builder().key(InputConstants.KEY_P).ctrl().action((it) -> {
        LOGGER.info("Keybind 'keybinding' (Ctrl+P) {}", it ? "pressed" : "released");
        Platform.compatibility().displayChatMessage(it ? "pressed keybind" : "released keybind");
    }).register();
    @Slider(title = "Slide", min = 10f, max = 110f, icon = "assets/oneconfig/ico/paintbrush.svg", description = "I do sliding", category = "bob")
    public static float p = 50f;
    @Text(title = "Text")
    public static String text = "Hello world!";
    @Text(title = "Multiline Text", description = "Supports line breaks and word wrap", multiline = true)
    public static String multilineText = "Hello world!\nThis is a second line.\noneconfigoneconfigoneconfigoneconfigoneconfigoneconfig";
    @Text(title = "Full Width Text", description = "The same text box spanning the whole row", multiline = true, fullWidth = true)
    public static String fullWidthText = "Hello world!\nThis is a second line.\noneconfigoneconfigoneconfigoneconfigoneconfigoneconfig";
    @File(title = "Image", description = "Pick an image file", types = {".png", ".jpg"}, filterName = "Images")
    public static String image = "";
    @File(title = "Directory", description = "Pick a folder", directory = true)
    public static String folder = "";
    @Dropdown(title = "A dropdown", description = "I do dropping (on Tuesdays)", options = {"A", "B", "C", "SADW", "AS", "FGAW", "ASDA", "ASDFHUA", "ASHDUIW", "HAWSUDIHWAUI", "&SHAJD", "AWSHUID"})
    public static int i = 0;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow2 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow3 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow4 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cow5 = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean acow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean scow = false;
    @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean cgow = false;
    @Switch(title = "Cow 2", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c2ow = false;
    @Switch(title = "Cow 3", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c3ow = false;
    @Switch(title = "Cow 4", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c4ow = false;
    @Switch(title = "Cow 5", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
    public static boolean c5ow = false;
    @RadioButton(title = "radio", description = "send help", options = {"Option A", "Option B", "Option C"})
    public static int radio = 0;
    @Switch(title = "t")
    public boolean added = false;
    @Color(title = "color", category = "bob")
    int color = 0xFFFF0064;

    @Slider(title = "we slide", description = "so real", min = 10f, max = 70f)
    public float slide = 40f;

    @Slider(title = "Opacity", description = "Shows its value through a ValueFormatter", min = 0f, max = 100f, formatter = Percent.class)
    public int opacity = 75;

    @Keybind(title = "keybind")
    private final OneConfigKeybind bind = KeybindHelper.builder().ctrl().key(InputConstants.KEY_G).action((Consumer<Boolean>) (it) -> LOGGER.info("Keybind 'keybind' (Ctrl+G) {}", it ? "pressed" : "released")).register();

    @DraggableList(
            title = "Draggable List (order only)",
            description = "Drag to reorder. No checkboxes.",
            category = "Lists",
            subcategory = "Draggable"
    )
    public static String[] draggableOrder = {"Alpha", "Bravo", "Charlie", "Delta", "Echo"};

    @DraggableList(
            title = "Draggable List (with checkboxes)",
            description = "Drag to reorder. Check to enable.",
            category = "Lists",
            subcategory = "Draggable",
            options = {"Alpha", "Bravo", "Charlie", "Delta", "Echo"},
            checkable = true
    )
    public static String[] draggableCheckable = {"Alpha", "Charlie", "Echo"};

    @MultiSelectDropdown(
            title = "Multi-Select Dropdown",
            description = "Click to open. Check multiple items.",
            category = "Lists",
            subcategory = "Dropdown",
            options = {"Apple", "Banana", "Cherry", "Date", "Elderberry"}
    )
    public static boolean[] multiSelect = {true, false, true, false, false};

    @MultiSelectDropdown(
            title = "Single-Select List Dropdown",
            description = "Click to open. Pick one item.",
            category = "Lists",
            subcategory = "Dropdown",
            options = {"Option A", "Option B", "Option C", "Option D"},
            checkable = false
    )
    public static int singleSelectList = 0;

    @TextList(
            title = "Text List",
            description = "Type each entry. Add, remove and drag to reorder.",
            category = "Lists",
            subcategory = "Text List",
            placeholder = "Enter a name..."
    )
    public static String[] textList = {"Notch", "Herobrine"};

    @TextList(
            title = "Text List (validated)",
            description = "Must look like a domain. Max 3 entries, no reordering.",
            category = "Lists",
            subcategory = "Text List",
            placeholder = "example.com",
            regex = "^[\\w.-]+\\.[a-z]{2,}$",
            maxEntries = 3,
            reorderable = false,
            addText = "Add server"
    )
    public static String[] textListValidated = {"hypixel.net"};

    @TextList(
            title = "Text List (empty)",
            description = "Starts with no entries.",
            category = "Lists",
            subcategory = "Text List"
    )
    public static String[] textListEmpty = {};

    @ItemList(
            title = "Item List",
            description = "Search registered items and add several of them to an ordered list.",
            category = "Lists",
            subcategory = "Item List",
            maxEntries = 8
    )
    public static String[] itemList = {"minecraft:diamond_sword", "minecraft:golden_apple"};

    @ItemList(
            title = "Single Item",
            description = "The same picker limited to one selected item.",
            category = "Lists",
            subcategory = "Item List",
            maxEntries = 1,
            reorderable = false
    )
    public static String[] singleItem = {"minecraft:ender_pearl"};

    @EffectList(
            title = "Effect List",
            description = "Search registered status effects and add several of them to an ordered list.",
            category = "Lists",
            subcategory = "Effect List",
            maxEntries = 6
    )
    public static String[] effectList = {"minecraft:speed", "minecraft:night_vision"};

    @EffectList(
            title = "Single Effect",
            description = "The same picker limited to one selected effect.",
            category = "Lists",
            subcategory = "Effect List",
            maxEntries = 1,
            reorderable = false
    )
    public static String[] singleEffect = {"minecraft:strength"};

    @TestTilePicker_Test(
            title = "Tile Picker",
            description = "Search a set of colors and pick up to three of them.",
            category = "Lists",
            subcategory = "Tile Picker"
    )
    public static String[] tilePicker = {"test:blue"};

    @TestTileList_Test(
            title = "Swatch List",
            description = "Search a set of colors and add several of them to an ordered list.",
            category = "Lists",
            subcategory = "Tile List",
            maxEntries = 5
    )
    public static String[] swatchList = {"test:red", "test:green"};

    @TestTileList_Test(
            title = "Single Swatch",
            description = "The same list limited to one selected color.",
            category = "Lists",
            subcategory = "Tile List",
            maxEntries = 1,
            reorderable = false
    )
    public static String[] singleSwatch = {"test:purple"};

    @FileList(
            title = "File List",
            description = "Pick several files. Add, remove and drag to reorder.",
            category = "Lists",
            subcategory = "Other Lists",
            types = {".png", ".jpg"},
            filterName = "Images",
            addText = "Add image"
    )
    public static String[] fileList = {};

    @FileList(
            title = "Directory List",
            description = "Folders instead of files, max 3.",
            category = "Lists",
            subcategory = "Other Lists",
            directory = true,
            maxEntries = 3
    )
    public static String[] directoryList = {};

    @FileList(
            title = "Full Width File List",
            description = "The same file list spanning the whole row so long paths fit.",
            category = "Lists",
            subcategory = "Other Lists",
            fullWidth = true
    )
    public static String[] fullWidthFileList = {};

    @ColorList(
            title = "Color List",
            description = "Packed ARGB entries, each with its own picker.",
            category = "Lists",
            subcategory = "Other Lists",
            addText = "Add color"
    )
    public static int[] colorList = {0xFFFF5555, 0xFF55FF55, 0x8055AAFF};

    @NumberList(
            title = "Number List",
            description = "Number inputs with stepper arrows.",
            category = "Lists",
            subcategory = "Other Lists",
            min = 0f,
            max = 64f
    )
    public static int[] numberList = {1, 16, 64};

    @SliderList(
            title = "Slider List",
            description = "A slider per entry, no reordering.",
            category = "Lists",
            subcategory = "Other Lists",
            min = 0f,
            max = 1f,
            step = 0.05f,
            reorderable = false
    )
    public static float[] sliderList = {0.25f, 0.5f, 1f};

    @RangeSlider(
            title = "Range Slider",
            description = "Two handles, one field.",
            step = 5f
    )
    public static float[] range = {25f, 75f};

    @RangeNumber(
            title = "Range Number",
            description = "Two inputs, no track, for spans too wide to drag.",
            min = 0f,
            max = 1000000f
    )
    public static int[] rangeNumber = {1200, 36000};

    @RangeSliderList(
            title = "Range Slider List",
            description = "A two-handle slider per entry, stored flat as start, end pairs.",
            category = "Lists",
            subcategory = "Other Lists",
            step = 5f,
            addText = "Add range"
    )
    public static float[] rangeSliderList = {0f, 25f, 50f, 75f};

    @RangeNumberList(
            title = "Range Number List",
            description = "A pair of inputs per entry.",
            category = "Lists",
            subcategory = "Other Lists",
            min = 0f,
            max = 72000f,
            maxEntries = 4,
            addText = "Add range"
    )
    public static int[] rangeNumberList = {0, 600, 1200, 9600};

    // everything below is disabled rather than hidden while the master switch is off so that
    // disabled options can be checked for being non-interactable
    @Switch(
            title = "Master switch",
            description = "Turn off to disable every option in this subcategory.",
            category = "Dependencies",
            subcategory = "Disabled when off"
    )
    public static boolean dependencyMaster = true;

    @Switch(title = "Dependent switch", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static boolean dependentSwitch = false;

    @Checkbox(title = "Dependent checkbox", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static boolean dependentCheckbox = false;

    @Slider(title = "Dependent slider", min = 0f, max = 100f, category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static float dependentSlider = 25f;

    @Number(title = "Dependent number", unit = "px", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static int dependentNumber = 10;

    @Text(title = "Dependent text", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static String dependentText = "Cannot type here while disabled";

    @Dropdown(title = "Dependent dropdown", options = {"A", "B", "C"}, category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static int dependentDropdown = 0;

    @RadioButton(title = "Dependent radio", options = {"Option A", "Option B"}, category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static int dependentRadio = 0;

    @Color(title = "Dependent color", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static int dependentColor = 0xFF00AAFF;

    @Keybind(title = "Dependent keybind", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static OneConfigKeybind dependentBind = KeybindHelper.builder().key(InputConstants.KEY_K).register();

    @TextList(title = "Dependent text list", category = "Dependencies", subcategory = "Disabled when off")
    @DependsOn("dependencyMaster")
    public static String[] dependentTextList = {"Entry"};

    // second independent condition disabled only while both switches are on via addDependency in the constructor
    @Switch(title = "Second condition", category = "Dependencies", subcategory = "Multiple conditions")
    public static boolean dependencySecond = false;

    @Switch(title = "Disabled when both are on", category = "Dependencies", subcategory = "Multiple conditions")
    public static boolean dependentBoth = false;

    @Info(
            title = "Info",
            description = "This is an info message that may be useful to the player!",
            category = "Lists",
            subcategory = "Info"
    )
    public static String infoMessage = "";

    public TestConfig_Test() {
        super("test_mod.json", "Test Mod", Category.QOL);
        addDependency("c3ow", "c2ow");
        hideIf("c5ow", "c4ow");
        addDependency("dependentBoth", "both switches on",
                () -> dependencyMaster && dependencySecond ? Property.Display.DISABLED : Property.Display.SHOWN);
    }

    @Button(title = "Test")
    private void button() {
        Notifications.info("Button pressed", "The test button was clicked.");
    }

    public static TestConfig_Test getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new TestConfig_Test();
        }

        return INSTANCE;
    }

    public static class Percent implements ValueFormatter {
        @Override
        public String format(java.lang.Number value) {
            return value + "%";
        }
    }

    @Accordion(title = "an accordion", description = "AAAAAAAAAAAAAAAAAAAAAAAAAAH", index = 4)
    public static class AinnerAAAA {
        @Include
        public static boolean enabled = true;

        @Text(title = "Text")
        public static String text = "Hello world!";

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        @DependsOn("cow2")
        public static boolean cbow = false;

        @RadioButton(title = "radio when me when me when me:", description = "send help", options = {"Option A", "Option B", "Option C"})
        public static int radio2 = 0;

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        public static boolean cbo2w = false;

        @Switch(title = "Cow", description = "Something that is way too long and is going to be trimmed (I hope) because that is what its meant to do")
        public static boolean cbogw = false;
    }

    @Accordion(title = "Switch primary", description = "Expands and collapses the accordion when toggled", category = "Accordions", subcategory = "Every primary type")
    public static class SwitchPrimary {
        @Primary
        @Switch(title = "Enabled")
        public static boolean on = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Accordion(title = "Checkbox primary", description = "Starts collapsed and expands when ticked", category = "Accordions", subcategory = "Every primary type", collapsed = true)
    public static class CheckboxPrimary {
        @Primary
        @Checkbox(title = "Enabled")
        public static boolean on = false;

        @Number(title = "Number", unit = "px", min = 0f)
        public static int number = 12;

        @Dropdown(title = "Dropdown", options = {"A", "B", "C"})
        public static int dropdown = 0;
    }

    @Accordion(title = "Number primary", description = "Never changes whether the accordion is open", category = "Accordions", subcategory = "Every primary type")
    public static class NumberPrimary {
        @Primary
        @Number(title = "Amount", unit = "px", min = 0f)
        public static int amount = 24;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Color(title = "Color")
        public static int color = 0xFF55AAFF;
    }

    @Accordion(title = "Text primary", description = "A text box on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class TextPrimary {
        @Primary
        @Text(title = "Label")
        public static String label = "Hello world!";

        @Checkbox(title = "Checkbox")
        public static boolean box = false;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;
    }

    @Accordion(title = "Full width text primary", description = "Stacks the text box on its own row below the title", category = "Accordions", subcategory = "Every primary type")
    public static class FullWidthTextPrimary {
        @Primary
        @Text(title = "Notes", fullWidth = true)
        public static String notes = "Hello world!";

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Dropdown(title = "Dropdown", options = {"A", "B", "C"})
        public static int dropdown = 0;
    }

    @Accordion(title = "Color primary", description = "A color picker on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class ColorPrimary {
        @Primary
        @Color(title = "Color")
        public static int color = 0xFFFF0064;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Number(title = "Number", unit = "px", min = 0f)
        public static int number = 8;
    }

    @Accordion(title = "Keybind primary", description = "A keybind on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class KeybindPrimary {
        @Primary
        @Keybind(title = "Shortcut")
        public static OneConfigKeybind shortcut = KeybindHelper.builder().key(InputConstants.KEY_J).build();

        @Switch(title = "Switch")
        public static boolean flag = true;

        @RadioButton(title = "Radio", options = {"Option A", "Option B"})
        public static int radio = 0;
    }

    @Accordion(title = "Radio button primary", description = "Radio buttons on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class RadioPrimary {
        @Primary
        @RadioButton(title = "Choice", options = {"Option A", "Option B"})
        public static int choice = 0;

        @Checkbox(title = "Checkbox")
        public static boolean box = false;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Accordion(title = "Dropdown primary", description = "A dropdown on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class DropdownPrimary {
        @Primary
        @Dropdown(title = "Preset", options = {"Low", "Medium", "High"})
        public static int preset = 1;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Color(title = "Color")
        public static int color = 0xFF00AAFF;

        @Keybind(title = "Keybind")
        public static OneConfigKeybind bind = KeybindHelper.builder().key(InputConstants.KEY_L).build();
    }

    @Accordion(title = "Slider primary", description = "A slider on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class SliderPrimary {
        @Primary
        @Slider(title = "Level", min = 0f, max = 100f, formatter = Percent.class)
        public static int level = 60;

        @Keybind(title = "Keybind")
        public static OneConfigKeybind bind = KeybindHelper.builder().key(InputConstants.KEY_B).build();

        @Switch(title = "Switch")
        public static boolean flag = true;
    }

    @Accordion(title = "Button primary", description = "A button on the header row", category = "Accordions", subcategory = "Every primary type")
    public static class ButtonPrimary {
        @Primary
        @Button(title = "Run", text = "Run")
        private void run() {
            Notifications.info("Button primary", "The header button was clicked.");
        }

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Accordion(title = "Legacy head", description = "The switch on the header comes from a legacy @Include boolean", category = "Accordions", subcategory = "States")
    public static class LegacyInclude {
        @Include
        public static boolean enabled = true;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;
    }

    @Accordion(title = "Collapsed without a primary", description = "Starts closed and has no control on the header", category = "Accordions", subcategory = "States", collapsed = true)
    public static class CollapsedPlain {
        @Switch(title = "Switch")
        public static boolean flag = true;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Accordion(title = "Disabled primary", description = "Disabled while the root switch under Dependencies is off", category = "Accordions", subcategory = "States")
    public static class DisabledPrimary {
        @Primary
        @Switch(title = "Enabled")
        @DependsOn("dependencyMaster")
        public static boolean on = true;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;
    }

    @Accordion(title = "Dependent children", description = "Children are disabled while the primary is off", category = "Accordions", subcategory = "States")
    public static class DependentChildren {
        @Primary
        @Switch(title = "Active")
        public static boolean active = true;

        @Switch(title = "Dependent switch")
        @DependsOn("active")
        public static boolean childSwitch = false;

        @Slider(title = "Dependent slider", min = 0f, max = 100f)
        @DependsOn("active")
        public static int childSlider = 25;

        @Text(title = "Dependent text")
        @DependsOn("active")
        public static String childText = "Cannot type here while disabled";
    }

    @Accordion(title = "Explicit primary wins", description = "A Primary dropdown takes the header over a legacy @Include boolean", category = "Accordions", subcategory = "States")
    public static class ExplicitOverLegacy {
        @Include
        public static boolean enabled = true;

        @Primary
        @Dropdown(title = "Mode", options = {"Automatic", "Manual"})
        public static int mode = 0;

        @Switch(title = "Switch")
        public static boolean flag = true;
    }

    @Submenu(title = "Showcase", description = "Many option types across two categories, with an accordion and nested pages", icon = "assets/oneconfig/ico/layers.svg", category = "Submenus", subcategory = "Pages")
    public static class Showcase {
        @Switch(title = "Showcase switch", category = "First", subcategory = "Toggles")
        public static boolean flag = false;

        @Keybind(title = "Keybind", category = "First", subcategory = "Toggles")
        public static OneConfigKeybind bind = KeybindHelper.builder().key(InputConstants.KEY_F).build();

        @Checkbox(title = "Checkbox", category = "First", subcategory = "Toggles")
        public static boolean checkbox = false;

        @Number(title = "Number", unit = "ms", min = 100f, max = 2000f, category = "First", subcategory = "Values")
        public static int number = 500;

        @Slider(title = "Slider", formatter = Percent.class, category = "First", subcategory = "Values")
        public static int slider = 40;

        @Color(title = "Color", category = "First", subcategory = "Values")
        public static int color = 0xFFFFB347;

        @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"}, category = "First", subcategory = "Choices")
        public static int dropdown = 0;

        @RadioButton(title = "Radio button", options = {"One", "Two", "Three"}, category = "First", subcategory = "Choices")
        public static int radio = 1;

        @Text(title = "Text", category = "Second", subcategory = "Inputs")
        public static String text = "Hello world!";

        @File(title = "File", types = {".png", ".jpg"}, filterName = "Images", category = "Second", subcategory = "Inputs")
        public static String file = "";

        @TextList(title = "Text list", placeholder = "Entry", category = "Second", subcategory = "Inputs")
        public static String[] entries = {"One", "Two"};

        @Info(title = "Info", description = "Read-only information", category = "Second", subcategory = "Actions")
        public static String info = "";

        @Button(title = "Button", category = "Second", subcategory = "Actions")
        private void click() {
            Notifications.info("Showcase", "The button was clicked.");
        }

        @Accordion(title = "Slider accordion", description = "An accordion with a slider primary inside a page", category = "First", subcategory = "Values")
        public static class SliderAccordion {
            @Primary
            @Slider(title = "Slider", formatter = Percent.class)
            public static int level = 50;

            @Switch(title = "Switch")
            public static boolean flag = true;

            @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
            public static int dropdown = 0;
        }

        @Submenu(title = "Nested page", description = "A page with a dropdown primary opened from another page", icon = "assets/oneconfig/ico/maximise.svg", category = "First", subcategory = "Choices")
        public static class NestedPage {
            @Primary
            @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
            public static int choice = 0;

            @Number(title = "Number", min = 0f, max = 500f)
            public static int number = 100;

            @Switch(title = "Switch")
            public static boolean flag = true;
        }

        @Submenu(title = "Deeper page", description = "A page that opens a third level", icon = "assets/oneconfig/ico/cog.svg", category = "Second", subcategory = "Actions")
        public static class DeeperPage {
            @Info(title = "Info", description = "Pages can nest up to three levels")
            public static String information = "";

            @Switch(title = "Switch")
            public static boolean flag = false;

            @Submenu(title = "Deepest page", description = "The third level", icon = "assets/oneconfig/ico/refresh.svg")
            public static class DeepestPage {
                @Primary
                @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
                public static int choice = 1;

                @Switch(title = "Switch")
                public static boolean flag = true;

                @Info(title = "Info", description = "Opened from the second level")
                public static String note = "";
            }
        }
    }

    @Submenu(title = "Switch primary", description = "A switch on the row", category = "Submenus", subcategory = "Every primary type")
    public static class SwitchPrimarySubmenu {
        @Primary
        @Switch(title = "Switch")
        public static boolean on = true;
        @Checkbox(title = "Checkbox")
        public static boolean checkbox = true;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Submenu(title = "Checkbox primary", description = "A checkbox on the row", category = "Submenus", subcategory = "Every primary type")
    public static class CheckboxPrimarySubmenu {
        @Primary
        @Checkbox(title = "Checkbox")
        public static boolean on = true;
        @Switch(title = "Switch")
        public static boolean flag = false;

        @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
        public static int dropdown = 1;
    }

    @Submenu(title = "Number primary", description = "A number field on the row", category = "Submenus", subcategory = "Every primary type")
    public static class NumberPrimarySubmenu {
        @Primary
        @Number(title = "Number", min = 0f)
        public static int value = 50;
        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider")
        public static int slider = 25;
    }

    @Submenu(title = "Text primary", description = "A text box on the row", category = "Submenus", subcategory = "Every primary type")
    public static class TextPrimarySubmenu {
        @Primary
        @Text(title = "Text")
        public static String value = "Hello world!";
        @Color(title = "Color")
        public static int color = 0xFF8855FF;

        @Switch(title = "Switch")
        public static boolean flag = true;
    }

    @Submenu(title = "Color primary", description = "A color picker on the row", category = "Submenus", subcategory = "Every primary type")
    public static class ColorPrimarySubmenu {
        @Primary
        @Color(title = "Color")
        public static int value = 0xFF0067C0;
        @Slider(title = "Slider", min = 0f, max = 100f, formatter = Percent.class)
        public static int slider = 80;

        @Text(title = "Text")
        public static String text = "Hello world!";
    }

    @Submenu(title = "Keybind primary", description = "A keybind on the row", category = "Submenus", subcategory = "Every primary type")
    public static class KeybindPrimarySubmenu {
        @Primary
        @Keybind(title = "Keybind")
        public static OneConfigKeybind value = KeybindHelper.builder().key(InputConstants.KEY_H).build();
        @Switch(title = "Switch")
        public static boolean flag = false;

        @Number(title = "Number", unit = "ms", min = 0f, max = 2000f)
        public static int number = 250;
    }

    @Submenu(title = "Radio button primary", description = "Radio buttons on the row", category = "Submenus", subcategory = "Every primary type")
    public static class RadioPrimarySubmenu {
        @Primary
        @RadioButton(title = "Radio button", options = {"One", "Two", "Three"})
        public static int value = 1;
        @Switch(title = "Switch")
        public static boolean flag = false;

        @Slider(title = "Slider", min = 0f, max = 100f, formatter = Percent.class)
        public static int slider = 20;
    }

    @Submenu(title = "Dropdown primary", description = "A dropdown on the row", category = "Submenus", subcategory = "Every primary type")
    public static class DropdownPrimarySubmenu {
        @Primary
        @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
        public static int value = 1;
        @Switch(title = "Switch")
        public static boolean flag = false;

        @Number(title = "Number", unit = "min", min = 0f, max = 240f)
        public static int number = 60;
    }

    @Submenu(title = "Slider primary", description = "A slider on the row", category = "Submenus", subcategory = "Every primary type")
    public static class SliderPrimarySubmenu {
        @Primary
        @Slider(title = "Slider", min = 0f, max = 100f, formatter = Percent.class)
        public static int value = 45;
        @Switch(title = "Switch")
        public static boolean flag = false;

        @Dropdown(title = "Dropdown", options = {"One", "Two", "Three"})
        public static int dropdown = 0;
    }

    @Submenu(title = "Button primary", description = "A button on the row", category = "Submenus", subcategory = "Every primary type")
    public static class ButtonPrimarySubmenu {
        @Primary
        @Button(title = "Run", text = "Run")
        private void run() {
            Notifications.info("Button primary", "The row button was clicked.");
        }
        @Checkbox(title = "Checkbox")
        public static boolean checkbox = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 7;

        @Info(title = "Info", description = "Read-only information")
        public static String info = "";
    }

    @Submenu(title = "Converted from an accordion", description = "The switch on the row comes from a legacy @Include boolean", category = "Submenus", subcategory = "States")
    public static class LegacySubmenu {
        @Include
        public static boolean enabled = true;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;
    }

    @Submenu(title = "Dependent children", description = "Children follow a sibling switch and the root switch", category = "Submenus", subcategory = "States")
    public static class DependentSubmenu {
        @Primary
        @Switch(title = "Active")
        public static boolean active = true;

        @Switch(title = "Follows the primary")
        @DependsOn("active")
        public static boolean followsPrimary = false;

        @Switch(title = "Follows the root switch")
        @DependsOn("dependencyMaster")
        public static boolean followsRoot = false;

        @Slider(title = "Follows both", min = 0f, max = 100f)
        @DependsOn({"active", "dependencyMaster"})
        public static int followsBoth = 25;
    }

    @Submenu(title = "Disabled primary", description = "Disabled while the root switch under Dependencies is off", category = "Submenus", subcategory = "States")
    public static class DisabledPrimarySubmenu {
        @Primary
        @Switch(title = "Enabled")
        @DependsOn("dependencyMaster")
        public static boolean on = true;

        @Switch(title = "Switch")
        public static boolean flag = true;

        @Slider(title = "Slider", min = 0f, max = 100f)
        public static int slider = 50;
    }
}
