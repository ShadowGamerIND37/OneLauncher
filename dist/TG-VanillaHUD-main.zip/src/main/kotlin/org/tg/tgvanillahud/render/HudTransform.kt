package org.tg.tgvanillahud.render

//? if > 1.8.9 {
import net.minecraft.client.gui.GuiGraphicsExtractor
//?} else {
/*import org.tg.tgvanillahud.compat.GuiGraphicsExtractor
*///?}
import org.tg.tgoneconfig.api.hud.v1.Hud
import org.tg.tgoneconfig.api.hud.v1.HudManager
import org.tg.tgvanillahud.hud.HudInternals
import org.tg.tgvanillahud.hud.Huds
import org.tg.tgvanillahud.hud.TabListHud
import org.tg.tgvanillahud.hud.VanillaHud
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

//? if <=1.21.5 && >1.8.9 {
/*import com.mojang.math.Axis
*///?}

object HudTransform {
    private var depth = 0

    private var scissors = IntArray(8)
    private var scissorDepth = 0
    private const val PUSHED = 0
    private const val SCISSORED = 1
    private const val SKIPPED = 2

    /** quarter turns to undo per icon while an icon layer draws */
    @JvmStatic
    var iconTurns = 0
        private set
    private var iconDepth = 0

    /** open [beginUpright] blocks, which already move their content so [mirrorShift] leaves it alone */
    private var uprightDepth = 0

    /** per open [begin], twice the centre y of a [VanillaHud.mirrored] element or NaN, kept unboxed */
    private var mirrors = FloatArray(8)
    private var mirrorDepth = 0
    private var mirror2Y = Float.NaN

    private fun pushScissor(state: Int) {
        if (scissorDepth == scissors.size) scissors = scissors.copyOf(scissorDepth * 2)
        scissors[scissorDepth++] = state
    }

    private fun push(graphics: GuiGraphicsExtractor) {
        graphics.pose().pushMatrix()
        depth++
    }

    private fun pop(graphics: GuiGraphicsExtractor) {
        if (depth <= 0) return
        depth--
        try {
            graphics.pose().popMatrix()
        } catch (_: RuntimeException) {
        }
    }

    private fun resolve(provider: VanillaHud): VanillaHud? =
        HudManager.activeInstances.firstOrNull(provider.javaClass::isInstance) as VanillaHud?

    private var resolveGen = 0

    private fun resolveCached(provider: VanillaHud): VanillaHud? {
        if (provider.resolvedGen != resolveGen) {
            provider.resolvedGen = resolveGen
            provider.resolved = resolve(provider)
        }
        return provider.resolved
    }

    private var resolvedFrom: Array<Hud> = emptyArray()

    private fun instancesChanged(): Boolean {
        val list = HudManager.activeInstances
        val n = list.size
        var changed = n != resolvedFrom.size
        if (!changed) {
            for (i in 0 until n) {
                if (list[i] !== resolvedFrom[i]) {
                    changed = true
                    break
                }
            }
        }
        if (changed) resolvedFrom = Array(n) { list[it] }
        return changed
    }

    /**
     * The HUD the options actually live on.
     *
     * [resolve] exists because TGOneConfig registers the instance the mixins hold as a provider and
     * deserialises the configured copies into [HudManager.activeInstances] separately. The user's
     * settings land on that copy, so anything option shaped has to be read off it rather than off
     * the template, or it reads back as the field default.
     */
    @JvmStatic
    // resolve only hands back instances of the provider's own class
    @Suppress("UNCHECKED_CAST")
    fun <T : VanillaHud> live(provider: T): T = (resolveCached(provider) ?: provider) as T

    private class Placement {
        var valid = false
        var frame = -1L
        var w = 0
        var h = 0
        var natW = 0f
        var natH = 0f
        var boxW = 0f
        var boxH = 0f
        var turns = 0
        var mirrored = false
        var elementScale = 1f
        var offX = 0f
        var offY = 0f
        var rev = 0
        var foreignRev = 0
        var scoreboardRev = 0
        var huds = 0
        var schema = 0
        var hx = 0f
        var hy = 0f
        var hud: VanillaHud? = null
        var s = 1f
        var ox = 0f
        var oy = 0f
        var gx = 0f
        var gy = 0f
    }

    private val placements = HashMap<Class<out VanillaHud>, Placement>()

    @JvmStatic
    fun placesStatBars() = !HudManager.isSamplingVanilla &&
        !Huds.health.isDrawnAsVanilla && !Huds.armor.isDrawnAsVanilla &&
        !Huds.hunger.isDrawnAsVanilla && !Huds.air.isDrawnAsVanilla

    /** [part] tells apart the game's HUD elements that draw into the same [provider], see [HudCapture.begin] */
    @JvmStatic
    @JvmOverloads
    fun begin(graphics: GuiGraphicsExtractor, provider: VanillaHud, part: Int = 0) {
        val editing = HudManager.isEditing
        val resolvedHud = resolveCached(provider)
        val src = resolvedHud ?: provider
        if (HudManager.isSamplingVanilla || src.isDrawnAsVanilla || !editing && !src.hasContent()) {
            pushScissor(SKIPPED)
            ForeignTransform.enterSkipped()
            return
        }
        ForeignTransform.enter(graphics, src)
        val w = ForeignTransform.realGuiWidth(graphics)
        val h = ForeignTransform.realGuiHeight(graphics)
        val p = placements.getOrPut(provider.javaClass) { Placement() }
        val again = !editing && p.valid && p.frame == VanillaHud.frame && p.w == w && p.h == h
        val turns = if (again) p.turns else src.quarterTurns
        val natW = if (again) p.natW else src.unrotatedWidth
        val natH = if (again) p.natH else src.unrotatedHeight
        if (!again && (editing || !p.valid || p.w != w || p.h != h || p.natW != natW || p.natH != natH || p.turns != turns || p.boxW != src.boxWidth || p.boxH != src.boxHeight || p.oy != src.vanillaOriginY(w, h) ||
            p.rev != VanillaHud.positionRevision || p.foreignRev != ForeignTransform.revision || p.scoreboardRev != HudInternals.scoreboardRevision ||
            p.huds != HudManager.activeInstances.size || p.hud !== resolvedHud || p.schema != (resolvedHud?.posSchema ?: 0) ||
            resolvedHud.let { it != null && (it.frameX != p.hx || it.frameY != p.hy || it.frameScale != p.s) })
        ) {
            val hud = resolvedHud
            hud?.reseedDefaultForScreen()
            val anchored = hud != null && hud.anchorsToVanillaOrigin()
            val s = hud?.frameScale ?: 1f
            if (anchored && editing) hud.pinToVanillaOrigin(w, h, s)
            val defX = src.scaledOriginX(w, h, s)
            val defY = src.scaledOriginY(w, h, s)
            p.hud = hud
            p.s = s
            p.ox = src.vanillaOriginX(w, h)
            p.oy = src.vanillaOriginY(w, h)
            val fx = hud?.frameX
            val fy = hud?.frameY
            p.hx = fx ?: 0f
            p.hy = fy ?: 0f
            p.gx = if (fx == null || anchored && !editing) defX else fx
            p.gy = if (fy == null || anchored && !editing) defY else fy
            p.valid = !editing
            p.w = w
            p.h = h
            p.natW = natW
            p.natH = natH
            p.boxW = src.boxWidth
            p.boxH = src.boxHeight
            p.turns = turns
            p.rev = VanillaHud.positionRevision
            p.foreignRev = ForeignTransform.revision
            p.scoreboardRev = HudInternals.scoreboardRevision
            p.huds = HudManager.activeInstances.size
            p.schema = hud?.posSchema ?: 0
        }
        if (!again) {
            p.mirrored = src.mirrored
            p.elementScale = src.elementScale
            p.offX = src.contentOffsetX
            p.offY = src.contentOffsetY
        }
        p.frame = VanillaHud.frame
        val hud = p.hud
        val s = p.s
        val ox = p.ox
        val oy = p.oy
        val gx = p.gx
        val gy = p.gy

        HudCapture.begin(src, part)
        val elementScale = p.elementScale
        var scissored = false
        val tab = src as? TabListHud
        if (tab != null && tab.animation && !editing) {
            val frac = tab.clipFraction()
            if (frac < 1f) {
                val foreign = if (frac > 0f) tab.foreignBounds() else null
                val tabScale = s * elementScale
                val top = if (foreign != null) gy + (foreign.top - oy) * tabScale else gy
                val clipH = (foreign?.height ?: src.height) * tabScale
                graphics.enableScissor(0, floor(top).toInt(), w, ceil(top + clipH * frac).toInt())
                scissored = true
            }
        }
        pushScissor(if (scissored) SCISSORED else PUSHED)

        // rotate about the content centre then shift so the rotated bounding box lands on gx gy
        val rotW = if (turns % 2 != 0) natH else natW
        val rotH = if (turns % 2 != 0) natW else natH
        val mirrored = p.mirrored
        val drawTurns = if (mirrored) (turns + 2) % 4 else turns
        val theta = drawTurns * (PI.toFloat() / 2f)
        val turned = drawTurns != 0

        mirror2Y = if (mirrored) 2f * oy + natH else Float.NaN
        if (mirrorDepth == mirrors.size) mirrors = mirrors.copyOf(mirrorDepth * 2)
        mirrors[mirrorDepth++] = mirror2Y

        push(graphics)
        ForeignTransform.rebase(graphics)
        val pose = graphics.pose()
        val drawn = s * elementScale
        val contentX = gx + p.offX * s
        val contentY = gy + p.offY * s
        HudCapture.place(p.hx, p.hy, gx, gy, s, contentX, contentY)
        //? if <=1.21.5 && >1.8.9 {
        /*pose.translate(contentX, contentY, 0f)
        pose.scale(drawn, drawn, 1f)
        if (turned) {
            pose.translate(rotW / 2f, rotH / 2f, 0f)
            pose.mulPose(Axis.ZP.rotation(theta))
            pose.translate(-natW / 2f - ox, -natH / 2f - oy, 0f)
        } else {
            pose.translate(-ox, -oy, 0f)
        }
        *///?} else {
        pose.translate(contentX, contentY)
        pose.scale(drawn, drawn)
        if (turned) {
            pose.translate(rotW / 2f, rotH / 2f)
            pose.rotate(theta)
            pose.translate(-natW / 2f - ox, -natH / 2f - oy)
        } else {
            pose.translate(-ox, -oy)
        }
        //?}
        ForeignTransform.recordPlacedPose(graphics)
    }

    /** marks a layer whose sprites are standalone icons so each one can be kept upright */
    @JvmStatic
    @JvmOverloads
    fun beginIcons(graphics: GuiGraphicsExtractor, provider: VanillaHud, part: Int = 0) {
        begin(graphics, provider, part)
        if (iconDepth++ == 0) iconTurns = drawTurns(live(provider))
    }

    private var iconRunHud: VanillaHud? = null
    private var iconRunDrawn = false

    @JvmStatic
    fun iconRun(graphics: GuiGraphicsExtractor, provider: VanillaHud): Boolean {
        if (provider === iconRunHud) return iconRunDrawn
        endIconRun(graphics)
        val drawn = provider.shouldDraw()
        iconRunHud = provider
        iconRunDrawn = drawn
        if (drawn) beginIcons(graphics, provider)
        return drawn
    }

    @JvmStatic
    fun endIconRun(graphics: GuiGraphicsExtractor) {
        if (iconRunHud == null) return
        val drawn = iconRunDrawn
        iconRunHud = null
        iconRunDrawn = false
        if (drawn) endIcons(graphics)
    }

    @JvmStatic
    fun resetFrame() {
        if (instancesChanged()) resolveGen++
        iconRunHud = null
        iconRunDrawn = false
        ForeignTransform.reset()
        iconDepth = 0
        iconTurns = 0
        depth = 0
        scissorDepth = 0
        uprightDepth = 0
        mirrorDepth = 0
        mirror2Y = Float.NaN
    }

    @JvmStatic
    fun endIcons(graphics: GuiGraphicsExtractor) {
        if (--iconDepth <= 0) {
            iconDepth = 0
            iconTurns = 0
        }
        end(graphics)
    }

    @JvmStatic
    fun uprightIcon(graphics: GuiGraphicsExtractor, x: Int, y: Int, width: Int, height: Int): Boolean {
        if (iconTurns == 0) return false
        val theta = -iconTurns * (PI.toFloat() / 2f)
        val cx = x + width / 2f
        val cy = y + height / 2f + mirrorShift(y, y + height)
        push(graphics)
        val pose = graphics.pose()
        //? if <=1.21.5 && >1.8.9 {
        /*pose.translate(cx, cy, 0f)
        pose.mulPose(Axis.ZP.rotation(theta))
        pose.translate(-cx, -cy, 0f)
        *///?} else {
        pose.translate(cx, cy)
        pose.rotate(theta)
        pose.translate(-cx, -cy)
        //?}
        return true
    }

    private fun drawTurns(hud: VanillaHud): Int = when {
        hud.isDrawnAsVanilla -> 0
        hud.mirrored -> (hud.quarterTurns + 2) % 4
        else -> hud.quarterTurns
    }

    /** how far to move a piece from [y0] to [y1] to reach its flipped height */
    @JvmStatic
    fun mirrorShift(y0: Int, y1: Int): Int {
        if (mirror2Y.isNaN() || uprightDepth > 0) return 0
        return (mirror2Y - y0 - y1).roundToInt()
    }

    /** keeps content around [cx] [cy] upright when rotated, or moves it to its flipped height */
    @JvmStatic
    fun beginUpright(graphics: GuiGraphicsExtractor, provider: VanillaHud, cx: Float, cy: Float) {
        val turns = drawTurns(live(provider))
        if (turns == 0 && mirror2Y.isNaN()) return
        push(graphics)
        uprightDepth++
        val pose = graphics.pose()
        if (!mirror2Y.isNaN()) {
            //? if <=1.21.5 && >1.8.9 {
            /*pose.translate(0f, mirror2Y - 2f * cy, 0f)
            *///?} else
            pose.translate(0f, mirror2Y - 2f * cy)
        }
        if (turns == 0) return
        val theta = -turns * (PI.toFloat() / 2f)
        //? if <=1.21.5 && >1.8.9 {
        /*pose.translate(cx, cy, 0f)
        pose.mulPose(Axis.ZP.rotation(theta))
        pose.translate(-cx, -cy, 0f)
        *///?} else {
        pose.translate(cx, cy)
        pose.rotate(theta)
        pose.translate(-cx, -cy)
        //?}
    }

    @JvmStatic
    fun endUpright(graphics: GuiGraphicsExtractor, provider: VanillaHud) {
        if (uprightIsNoop(provider)) return
        if (uprightDepth > 0) uprightDepth--
        pop(graphics)
    }

    @JvmStatic
    fun endUprightIcon(graphics: GuiGraphicsExtractor) {
        pop(graphics)
    }

    private fun uprightIsNoop(provider: VanillaHud) = mirror2Y.isNaN() && drawTurns(live(provider)) == 0

    /** like [begin] for an element drawn as text, which is kept upright around its own centre */
    @JvmStatic
    fun beginText(graphics: GuiGraphicsExtractor, hud: VanillaHud) {
        begin(graphics, hud)
        val w = ForeignTransform.realGuiWidth(graphics)
        val h = ForeignTransform.realGuiHeight(graphics)
        beginUpright(
            graphics, hud,
            hud.vanillaOriginX(w, h) + hud.naturalWidth / 2f,
            hud.vanillaOriginY(w, h) + hud.naturalHeight / 2f,
        )
    }

    @JvmStatic
    fun endText(graphics: GuiGraphicsExtractor, hud: VanillaHud) {
        endUpright(graphics, hud)
        end(graphics)
    }

    @JvmStatic
    fun end(graphics: GuiGraphicsExtractor) {
        val state = if (scissorDepth > 0) scissors[--scissorDepth] else -1
        ForeignTransform.leave()
        if (state == SKIPPED) return
        if (mirrorDepth > 0) mirrorDepth--
        mirror2Y = if (mirrorDepth > 0) mirrors[mirrorDepth - 1] else Float.NaN
        pop(graphics)
        if (state == SCISSORED) graphics.disableScissor()
        HudCapture.end()
    }
}
