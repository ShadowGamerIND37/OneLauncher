plugins {
    id("dev.kikugie.stonecutter")
}

stonecutter active "26.3-fabric"
stonecutter tasks {
    order("publishModrinth")
    order("publishCurseforge")
}

tasks.register("publishMods") {
    group = "publishing"
    description = "Publishes all nodes to Modrinth and CurseForge."
    dependsOn(stonecutter.tasks.named("publishMods"))
}

stonecutter handlers {
    inherit("aw", "classtweaker")
}

stonecutter {
    parameters {
        constants {
            match(
                current.project.substringAfterLast("-"),
                "fabric",
                "ornithe"
            )
            val catalogue = rootProject.getForwardingVersionCatalog(current)

            this["sdl"] = eval(current.version, ">= 26.3") || eval(current.version, "= 1.8.9")

            this["moul_compat"] = current.project.endsWith("-fabric") && catalogue.has("moulconfig")
            this["yacl_compat"] = catalogue.has("yacl")
            this["clothconfig_compat"] = catalogue.has("clothconfig")
            this["midnightlib_compat"] = catalogue.has("midnightlib")
            this["walksylib_compat"] = catalogue.has("walksylib")
            this["modmenu_compat"] = catalogue.has("modmenu")
            this["rconfig_compat"] = catalogue.has("rconfig")
            this["osl_config_compat"] = current.project.endsWith("-ornithe")
            this["dandelion_compat"] = catalogue.has("dandelion")
            this["odin_compat"] = current.project.endsWith("-fabric") && catalogue.has("odin")
            this["mlib_compat"] = current.project.endsWith("-fabric") && catalogue.has("meowdding-lib")
            this["skyblocker_compat"] = current.project.endsWith("-fabric") && catalogue.has("skyblocker")
            this["stella_compat"] = current.project.endsWith("-fabric") && catalogue.has("stella")
            // Hypixel SkyBlock can only be played on 26.1 and above
            this["skyblock"] = eval(current.version, ">= 26.1")
            this["tr7zw_compat"] = true
            this["ukulib_compat"] = current.project.endsWith("-fabric")
            this["axolotlclient_config_compat"] = true
            this["wwaypoints_compat"] = current.project.endsWith("-fabric")
            this["cinnabar"] = catalogue.has("cinnabar") && rootProject.hasProperty("minecraft.vulkan")
            this["vulkanmod"] = current.project.endsWith("-fabric") && catalogue.has("vulkanmod")
        }

        replacements {
            string(eval(current.version, "< 26.1")) {
                replace("classTweaker v1 official", "classTweaker v1 named")
            }

            string(eval(current.version, ">= 26.1"), "gui_graphics") {
                replace("GuiGraphics", "GuiGraphicsExtractor")
            }

            string(eval(current.version, "< 26.1")) {
                replace(
                    "import net.minecraft.client.gui.GuiGraphicsExtractor\n",
                    "import net.minecraft.client.gui.GuiGraphics as GuiGraphicsExtractor\n",
                )
            }
            // 26.2 moved the main render target from Minecraft onto GameRenderer
            string(eval(current.version, ">= 26.2"), "main_render_target") {
                replace("mainRenderTarget", "gameRenderer.mainRenderTarget()")
            }
            string(eval(current.version, "< 1.21.11", "> 1.8.9")) {
                replace(
                    "import net.minecraft.resources.Identifier\n",
                    "import net.minecraft.resources.ResourceLocation as Identifier\n",
                )
            }
            string(eval(current.version, "= 1.8.9")) {
                replace(
                    "import net.minecraft.resources.Identifier\n",
                    "import net.minecraft.resource.Identifier\n",
                )
            }

            string(eval(current.version, "< 1.21.2")) {
                replace("Minecraft.getInstance().schedule(", "Minecraft.getInstance().tell(")
            }

            string(eval(current.version, "= 1.8.9")) {
                replace(
                    "com.mojang.blaze3d.platform.InputConstants",
                    "org.tg.tgoneconfig.internal.legacy.InputConstants"
                )
                replace(
                    "com.mojang.blaze3d.platform.NativeImage",
                    "org.tg.tgoneconfig.internal.legacy.NativeImage"
                )
                replace(
                    "net.kyori.adventure.platform.fabric.FabricClientAudiences",
                    "org.tg.tgoneconfig.internal.legacy.FabricClientAudiences"
                )
                replace(
                    "net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource",
                    "org.tg.tgoneconfig.internal.legacy.command.FabricClientCommandSource"
                )
                replace(
                    "net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback",
                    "org.tg.tgoneconfig.internal.legacy.command.ClientCommandRegistrationCallback"
                )
                replace(
                    "net.minecraft.client.resources.sounds.SimpleSoundInstance",
                    "org.tg.tgoneconfig.internal.legacy.SimpleSoundInstance"
                )
                replace(
                    "net.minecraft.sounds.SoundEvents",
                    "org.tg.tgoneconfig.internal.legacy.SoundEvents"
                )
                replace(
                    "net.minecraft.network.chat.Component",
                    "org.tg.tgoneconfig.internal.legacy.chat.Component"
                )
                replace(
                    "net.minecraft.network.chat.MutableComponent",
                    "org.tg.tgoneconfig.internal.legacy.chat.MutableComponent"
                )
                replace(
                    "net.minecraft.network.chat.Style",
                    "org.tg.tgoneconfig.internal.legacy.chat.Style"
                )
                replace(
                    "net.minecraft.ChatFormatting",
                    "org.tg.tgoneconfig.internal.legacy.chat.ChatFormatting"
                )
                replace(
                    "net.minecraft.network.chat.FormattedText",
                    "org.tg.tgoneconfig.internal.legacy.chat.FormattedText"
                )
                replace(
                    "net.minecraft.util.FormattedCharSequence",
                    "org.tg.tgoneconfig.internal.legacy.chat.FormattedCharSequence"
                )
                replace(
                    "net.minecraft.util.FormattedCharSink",
                    "org.tg.tgoneconfig.internal.legacy.chat.FormattedCharSink"
                )
                replace(
                    "net.minecraft.server.Bootstrap",
                    "net.minecraft.Bootstrap"
                )
                replace(
                    "net.minecraft.client.gui.screens.Screen",
                    "net.minecraft.client.gui.screen.Screen"
                )
                replace(
                    "net.minecraft.client.gui.screens.TitleScreen",
                    "net.minecraft.client.gui.screen.menu.TitleScreen"
                )
                replace(
                    "net.minecraft.client.gui.screens.ChatScreen",
                    "net.minecraft.client.gui.screen.game.ChatScreen"
                )
                replace(
                    "net.minecraft.client.gui.screens.ConnectScreen",
                    "net.minecraft.client.gui.screen.menu.multiplayer.ConnectScreen"
                )
                replace(
                    "net.minecraft.client.gui.screens.ProgressScreen",
                    "net.minecraft.client.gui.screen.ProgressScreen"
                )
                replace(
                    "com.mojang.blaze3d.pipeline.RenderTarget",
                    "net.minecraft.client.render.pipeline.RenderTarget"
                )
                replace(
                    "com.mojang.blaze3d.platform.GlStateManager",
                    "net.minecraft.client.render.platform.GlStateManager"
                )
                replace(
                    "net.minecraft.server.packs.repository.RepositorySource",
                    "net.ornithemc.osl.resource.loader.api.resource.repository.ResourcePackRepository"
                )
                replace(
                    "net.minecraft.world.phys.HitResult",
                    "net.minecraft.world.HitResult"
                )
                replace(
                    "import net.minecraft.network.protocol.Packet",
                    "import net.minecraft.network.packet.Packet"
                )
                replace(
                    "net.minecraft.client.resources.sounds.SoundInstance",
                    "net.minecraft.client.sound.instance.SoundInstance"
                )
                replace(
                    "net.minecraft.client.resources.sounds.AbstractTickableSoundInstance",
                    "net.minecraft.client.sound.instance.AbstractTickableSoundInstance"
                )
                replace(
                    "net.minecraft.client.resources.language.I18n",
                    "net.ornithemc.osl.localization.api.L10n"
                )
                replace(
                    "net.minecraft.client.sounds.SoundManager",
                    "net.minecraft.client.sound.system.SoundManager"
                )
                replace(
                    "net.minecraft.client.sounds.SoundEngine",
                    "net.minecraft.client.sound.system.SoundEngine"
                )
                replace(
                    "net.minecraft.sounds.SoundSource",
                    "net.minecraft.client.sound.SoundCategory"
                )
                replace(
                    "net.minecraft.client.renderer.entity.LivingEntityRenderer",
                    "net.minecraft.client.render.entity.LivingEntityRenderer"
                )
                replace(
                    "net.minecraft.world.entity.LivingEntity",
                    "net.minecraft.entity.living.LivingEntity"
                )
                replace(
                    "net.minecraft.world.item",
                    "net.minecraft.item"
                )
                replace(
                    "net.minecraft.server.packs.resources.PreparableReloadListener",
                    "net.ornithemc.osl.resource.loader.api.resource.reload.ResourceReloadListener"
                )
                replace(
                    "net.minecraft.server.packs.resources.ReloadableResourceManager",
                    "net.ornithemc.osl.resource.loader.api.resource.manager.ReloadableResourceManager"
                )
                replace(
                    "net.minecraft.server.packs.resources.ResourceManager",
                    "net.ornithemc.osl.resource.loader.api.resource.manager.ResourceManager"
                )
                replace(
                    "net.minecraft.server.packs.resources.SimpleReloadInstance",
                    "net.ornithemc.osl.resource.loader.impl.resource.manager.SimpleReloadableResourceManager"
                )
                replace(
                    "net.minecraft.core.Direction",
                    "net.minecraft.util.math.Direction"
                )
                replace(
                    "net.minecraft.server.packs.resources.ReloadInstance",
                    "net.ornithemc.osl.resource.loader.api.resource.reload.ResourceReload"
                )
                replace(
                    "net.minecraft.client.gui.components.DebugScreenOverlay",
                    "net.minecraft.client.gui.overlay.DebugOverlay"
                )
                replace(
                    "net.minecraft.client.renderer.texture.AbstractTexture",
                    "net.minecraft.client.render.texture.Texture"
                )
                replace(
                    "net.minecraft.client.renderer.texture.DynamicTexture",
                    "net.minecraft.client.render.texture.HttpTexture"
                )
                replace(
                    "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents",
                    "net.ornithemc.osl.networking.api.client.ClientConnectionEvents"
                )
            }

            string(eval(current.version, ">= 26.3")) {
                replace("com.mojang.blaze3d.opengl", "com.mojang.renderpearl.backend.opengl")
                replace("com.mojang.blaze3d.vulkan", "com.mojang.renderpearl.backend.vulkan")
                replace("com.mojang.blaze3d.textures", "com.mojang.renderpearl.api.textures")
                replace("com.mojang.blaze3d.buffers", "com.mojang.renderpearl.api.buffers")
                replace("com.mojang.blaze3d.GpuFormat", "com.mojang.renderpearl.api.GpuFormat")
                replace("com.mojang.blaze3d.systems.RenderPass", "com.mojang.renderpearl.api.commands.RenderPass")
                // mixin descriptors
                replace("com/mojang/blaze3d/systems/GpuSurface", "com/mojang/renderpearl/api/device/GpuSurface")
                replace("com/mojang/blaze3d/systems/CommandEncoder", "com/mojang/renderpearl/api/commands/CommandEncoder")
                replace("com/mojang/blaze3d/systems/RenderPass", "com/mojang/renderpearl/api/commands/RenderPass")
                replace("com/mojang/blaze3d/textures/GpuTextureView", "com/mojang/renderpearl/api/textures/GpuTextureView")
            }
        }
    }
}
