/*
 * This file is part of TGOneConfig.
 * TGOneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 TG.
 *   <https://github.com/ShadowGamerIND37> <https://github.com/TG/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   TGOneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to TGOneConfig, as published by TG,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to TGOneConfig, as published by TG. If not, see
 * <https://github.com/ShadowGamerIND37/legal/tgoneconfig/additional-terms>
 */

package org.tg.tgoneconfig.internal.mixin;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.server.packs.repository.RepositorySource;
import org.tg.tgoneconfig.internal.ui.sound.TGOneConfigSoundPackSource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

//? if > 1.8.9 {
import net.minecraft.client.resources.ClientPackSource;
import net.minecraft.server.packs.repository.PackRepository;
//?}

//? if = 1.8.9 {
/*import net.ornithemc.osl.resource.loader.api.resource.ResourceType;
import net.ornithemc.osl.resource.loader.impl.resource.repository.SimpleResourcePackRepository;
*///?}

//~ if = 1.8.9 'PackRepository' -> 'SimpleResourcePackRepository'
@Mixin(PackRepository.class)
public abstract class Mixin_PackRepository {
    @Mutable
    @Shadow
    @Final
    //~ if = 1.8.9 'RepositorySource' -> 'ResourcePackRepository.Source'
    private Set<RepositorySource> sources;

    //? if = 1.8.9 {
    /*@Shadow
    @Final
    private ResourceType type;
    *///?}

    //? if > 1.8.9 {
    @Inject(method = "<init>", at = @At("TAIL"))
    private void tgoneconfig$addSoundPack(RepositorySource[] sources, CallbackInfo ci) {
        boolean isClientResources = false;
        for (RepositorySource source : sources) {
            if (source instanceof ClientPackSource) {
                isClientResources = true;
                break;
            }
        }
        if (!isClientResources) return;

        Set<RepositorySource> combined = new LinkedHashSet<>(this.sources);
        combined.add(TGOneConfigSoundPackSource.INSTANCE);
        this.sources = combined;
    }
    //?} else {
    /*@Inject(method = "init", at = @At("TAIL"))
    private void tgoneconfig$addSoundPack(CallbackInfo ci) {
        if (this.type != ResourceType.CLIENT_ASSETS) return;

        this.sources.add(TGOneConfigSoundPackSource.INSTANCE);
    }
    *///?}
}
