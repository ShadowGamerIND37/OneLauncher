/*
 * This file is part of TGOneConfig.
 * TGOneConfig - Next Generation Config Library for Minecraft: Java Edition
 * Copyright (C) 2021~2024 TG.
 *   <https://github.com/ShadowGamerIND37> <https://github.com/TG/>
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *   TGOneConfig is licensed under the terms of version 3 of the GNU Lesser
 * General Public License as published by the Free Software Foundation, AND
 * under the Additional Terms Applicable to TGOneConfig, as published by TG,
 * either version 1.0 of the Additional Terms, or (at your option) any later
 * version.
 *
 *   This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 * License.  If not, see <https://www.gnu.org/licenses/>. You should
 * have also received a copy of the Additional Terms Applicable
 * to TGOneConfig, as published by TG. If not, see
 * <https://github.com/ShadowGamerIND37/legal/tgoneconfig/additional-terms>
 */

package org.tg.tgoneconfig.api.config.v1.collect;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.tg.tgoneconfig.api.config.v1.Tree;

/**
 * This functional interface represents a 'translator' which will take an object and return a {@link Tree} representing the serializable representation of the object
 * <br>
 * Changes to the tree should be reflected in the object and changes to the object in the tree
 */
@FunctionalInterface
public interface PropertyCollector {
    /**
     * Attempt to collect the properties of the given object
     *
     * @param src the object to collect from
     * @return the tree or null if this collector cannot parse it
     *         <br>
     *         If null is returned the next collector will be tried
     *         <br>
     *         This operation should be fail-fast
     */
    @Nullable
    Tree collect(@NotNull Object src);

}
